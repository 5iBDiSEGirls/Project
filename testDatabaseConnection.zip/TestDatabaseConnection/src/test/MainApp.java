package test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;


public class MainApp {

	public static void main(String[] args) {
		
		try
        {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");

            String userName = "test";
            String password = "Password1";
            String url = "jdbc:sqlserver://localhost:49156"+";databaseName=testschool";
            Connection con = DriverManager.getConnection(url, userName, password);
            Statement s1 = con.createStatement();
            ResultSet rs = s1.executeQuery("SELECT imie from uczniowie");
            String result = "";
            
            if(rs!=null){
                while (rs.next()){
                    result=rs.getString(1);
                    System.out.println(result);
                }
            }
//            String sql = "INSERT INTO uczniowie " +
//                    "VALUES (118, 'Artur', 'Mucha', '1989-04-05', 'ul.Rajdowa 18', '609545746', 6)";
//            s1.executeUpdate(sql);
            

            
            
        } catch (Exception e)
        {
            e.printStackTrace();
        }
		

	}

}
