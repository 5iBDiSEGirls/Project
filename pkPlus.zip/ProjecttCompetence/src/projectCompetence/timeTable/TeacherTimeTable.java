package projectCompetence.timeTable;


import java.awt.Desktop;
import java.io.File;
import java.io.IOException;
import java.sql.SQLException;

import javafx.beans.binding.Bindings;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.Label;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableRow;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import javafx.util.Callback;
import projectCompetence.DiaryOfTeacher;
import projectCompetence.MainApp;
import projectCompetence.Teacher.PersonRow;

@SuppressWarnings("rawtypes")
public class TeacherTimeTable {
	
	private Stage stage = new Stage();
    private final DiaryOfTeacher diaryOfTeacher = new DiaryOfTeacher("Dziennik");
    private final TableView<PersonRow> table = new TableView<>();
    
    private final ObservableList<PersonRow> data = diaryOfTeacher.getAllPeople();
    private final Label tableLabel = new Label("Brak osob w bazie.");
    
    @SuppressWarnings("unchecked")
	public TeacherTimeTable() throws Exception {
        Scene scene = new Scene(new Group(),800,450);
        stage.setTitle("Leggo - plan nauczyciela");
        stage.setResizable(false);
        
        String[] viewColumnNames = new String[] { "Nr", "Imi�", "Nazwisko","Edytuj"}; 
 
        String[] propertyValuesNames = new String[] { "personNumber", "firstName","lastName" ,"Edytuj"};
        double[] widthRatio = new double[] { 0.05, 0.14, 0.15,0.5};
   
 
        table.setPlaceholder(tableLabel);
        table.setPrefWidth(790);
        table.setRowFactory(this.createContextMenuTable());
        table.setItems(data);
        table.getColumns().addAll(this.createTableColumns(viewColumnNames, propertyValuesNames, widthRatio));
         
        final BorderPane borderPane = new BorderPane();
        borderPane.setPadding(new Insets(10));
       
        borderPane.setCenter(table);
       
 
        ((Group) scene.getRoot()).getChildren().addAll(borderPane);
 
        stage.setScene(scene);
        stage.show();
    }
  
    private EventHandler<ActionEvent> onEditEvent(TableRow<PersonRow> row) {
        return new EventHandler<ActionEvent>() {  
            @Override  
            public void handle(ActionEvent event) {
            	
            	
            	
            
				
            	
            }
        };
    }
    
    private Callback createContextMenuTable() {
        return new Callback<TableView<PersonRow>, TableRow<PersonRow>>() {  
            @Override  
            public TableRow<PersonRow> call(TableView<PersonRow> tableView) {  
                final TableRow<PersonRow> row = new TableRow<>();  
                final ContextMenu contextMenu = new ContextMenu();
                final MenuItem editMenuItem = new MenuItem("Otw�rz plan");  
                editMenuItem.setOnAction(onEditEvent(row));
                contextMenu.getItems().add(editMenuItem);  
                row.contextMenuProperty().bind(  
                        Bindings.when(row.emptyProperty())  
                        .then((ContextMenu)null)  
                        .otherwise(contextMenu)  
                );  
                return row;  
            }
        };
    }
    
	private TableColumn[] createTableColumns(String[] viewColumnNames, String[] propertyValuesNames, double[] widthRatio) {
        
        if (propertyValuesNames.length != viewColumnNames.length) {
            System.err.println("Nier�wna ilo�� nazw kolumn i parametr�w.");
            System.exit(1);
        }
        
        TableColumn[] returned = new TableColumn[viewColumnNames.length];
        
        for (int i = 0; i < viewColumnNames.length; ++i) {
            TableColumn tableColumn = new TableColumn(viewColumnNames[i]);
            tableColumn.prefWidthProperty().bind(table.widthProperty().multiply(widthRatio[i]));
            tableColumn.setCellValueFactory(new PropertyValueFactory<>(propertyValuesNames[i]));
            returned[i] = tableColumn;
        }
        
        return returned;
    }
    
   
    
    

    public void show() {
		this.stage.show();
		
	}
}


