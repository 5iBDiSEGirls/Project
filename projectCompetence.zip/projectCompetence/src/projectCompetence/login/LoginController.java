package projectCompetence.login;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import projectCompetence.MainApp;
import projectCompetence.welcomeStudent.StudentController;
import projectCompetence.welcomeTeacher.TeacherController;

public class LoginController implements Initializable{

	@FXML
	private Label logLab;
	@FXML
	private TextField textLogin;
	@FXML
	private PasswordField textHaslo;
	
	private MainApp mainApp;
	
	@FXML
	private void loginButtonAction(ActionEvent event) throws Exception{
		if(textLogin.getText().equals("nazwisko@leggo.com") && textHaslo.getText().equals("test")) {
			logLab.setText("Witaj " + textLogin.getText() + "!");
			TeacherController.showTeacher(mainApp);
		}else if(textLogin.getText().equals("nazwisko@leggo.com") && textHaslo.getText().equals("test2")) {
			logLab.setText("Witaj " + textLogin.getText() + "!");
			StudentController.showStudent(mainApp);
		}
		else {
			logLab.setText("Has�o nieprawid�owe!");
		}
	}

	@Override
	public void initialize(URL url, ResourceBundle rb) {
		// TODO Auto-generated method stub
		
	}

	public void setMainApp(MainApp mainApp) {
		this.mainApp = mainApp;
		
	}

}
