package projectCompetence.login;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import projectCompetence.welcomeTeacher.TeacherController;

public class LoginController implements Initializable{

	Stage stage;
	@FXML
	private Label logLab;
	@FXML
	private TextField textLogin;
	@FXML
	private PasswordField textHaslo;
	
	@FXML
	private void loginButtonAction(ActionEvent event) throws Exception{
		if(textLogin.getText().equals("test@leggo.com") && textHaslo.getText().equals("test")) {
			logLab.setText("Witaj " + textLogin.getText() + "!");
			TeacherController.showTeacher();
		}else {
			logLab.setText("Has�o nieprawid�owe!");
		}
	}

	@Override
	public void initialize(URL url, ResourceBundle rb) {
		// TODO Auto-generated method stub
		
	}
	public void setStage(Stage stage2) {
		stage = stage2;
		
	}

}
