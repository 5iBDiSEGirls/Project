package projectCompetence.welcomeTeacher;

import java.io.IOException;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import projectCompetence.MainApp;


public class TeacherController {
	
	Stage stage;
	
	private static BorderPane rootLayout;
	
	public void initRootLayout() {
        try {
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("welcomeTeacher/RootLayout.fxml"));
            rootLayout = (BorderPane)loader.load();
            Scene scene = new Scene(rootLayout);
            stage.setScene(scene);
            stage.setTitle("Zalogowany jako nauczyciel");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    public static void showWylogujScene(){
    	try{
    	
    	FXMLLoader loader = new FXMLLoader();
    	loader.setLocation(MainApp.class.getResource("view/Logout.fxml"));
    	AnchorPane Wyloguj = (AnchorPane)loader.load();
    	
    	rootLayout.setCenter(Wyloguj);
    	
    	} catch (IOException e) {
            e.printStackTrace();
        }
    }

	public static void showTeacher() {
		  try {
	            FXMLLoader loader = new FXMLLoader();
	            loader.setLocation(MainApp.class.getResource("welcomeTeacher/Teacher.fxml"));
	            AnchorPane Nauczyciel = (AnchorPane) loader.load();
	            rootLayout.setCenter(Nauczyciel);
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
		
	}

	public void setStage(Stage stage2) {
		stage = stage2;
	}

}
