package projectCompetence.welcomeStudent;

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import projectCompetence.MainApp;
import projectCompetence.welcomeTeacher.TeacherController;

public class StudentController {
private MainApp mainApp;
	
	private static AnchorPane rootLayout;
	@FXML
	private void LogoutButtonAction(ActionEvent event) throws Exception{
		if(MainApp.showQuestionDialog("Potwierdzenie", "Czy napewno chcesz sie wylogowa�?", "")) {
			mainApp.loadStage();
		}
	}
	public static void showStudent(MainApp mainApp) {
		try {
		  	
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(MainApp.class.getResource("welcomeStudent/Student.fxml"));
			rootLayout = loader.load();
			((StudentController) loader.getController()).setMainApp(mainApp);
			Scene scene = new Scene(rootLayout);
			mainApp.getStage().setScene(scene);
			mainApp.getStage().setTitle("Uczen");
		} catch (IOException e) {
		    e.printStackTrace();
		}
}
	private void setMainApp(MainApp mainApp) {
		this.mainApp = mainApp;
		
	}

}
