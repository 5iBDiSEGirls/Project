package projectCompetence;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.util.Optional;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonBar.ButtonData;
import javafx.scene.control.ButtonType;
import javafx.stage.Stage;
import projectCompetence.login.LoginController;

public class MainApp extends Application {    

	private Stage stage;
	
    @Override
    public void start(Stage stage) throws Exception{
    	this.stage = stage;
    	loadStage();
		stage.show();
    }
    
    public void loadStage() throws IOException {
    	FXMLLoader loader = new FXMLLoader();
    	loader.setLocation(getClass().getResource("login/LoginScene.fxml"));
    	Parent root = loader.load();
		Scene scene = new Scene(root);
		stage.setScene(scene);
		stage.setTitle("Logowanie w Leggo");
		((LoginController) loader.getController()).setMainApp(this);
    }
    
    public static boolean showQuestionDialog(String title, String headerText, String contentText) {
        Alert alert = new Alert(AlertType.CONFIRMATION);
        alert.setTitle(title);
        alert.setHeaderText(headerText);
        alert.setContentText(contentText);
        
        Optional<ButtonType> result = alert.showAndWait();
        return result.isPresent() && result.get().getButtonData() == ButtonData.OK_DONE;
    }
    
    public static Statement getStatement() throws ClassNotFoundException, SQLException {
    	Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		Connection con = DriverManager
				.getConnection("jdbc:sqlserver://project-competence.database.windows.net:1433;"
						+ "database=School;user=BDiSE@project-competence;password=dreamTeam1;encrypt=true;"
						+ "trustServerCertificate=false;hostNameInCertificate=*.database.windows.net;loginTimeout=30;");
		Statement s1 = con.createStatement();
		return s1;
    }
    
    public static Connection getConnection() throws ClassNotFoundException, SQLException {
    	Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		Connection con = DriverManager
				.getConnection("jdbc:sqlserver://project-competence.database.windows.net:1433;"
						+ "database=School;user=BDiSE@project-competence;password=dreamTeam1;encrypt=true;"
						+ "trustServerCertificate=false;hostNameInCertificate=*.database.windows.net;loginTimeout=30;");
		Statement s1 = con.createStatement();
		return con;
    }
    
    public static void main(String[] args) {
    	
        launch(args);

    }

	public Stage getStage() {
		return stage;
	}
}
