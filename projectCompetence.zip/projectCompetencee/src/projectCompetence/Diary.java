package projectCompetence;

import java.util.*;
import java.io.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import projectCompetence.Student.PersonRow;

public class Diary implements Serializable {
	
	private int nextPersonNumber;
	private Map<String, Student> listOfPerson;
	private File fileName;
	
	public Diary(String diaryName) {
		if (!this.loadInformation(new File(diaryName + ".dziennik"))) {
			this.nextPersonNumber = 1;
			this.listOfPerson = new HashMap<>();
			this.fileName = new File(diaryName + ".dziennik");
			this.saveInformation(this.fileName);
		}
	}
        
        private boolean loadInformation(File fileName) {
        	Diary loadedData = null;

            try {
                ObjectInputStream inStream = new ObjectInputStream(new FileInputStream(fileName));
                loadedData = (Diary)inStream.readObject();
                inStream.close();
            }
            catch(IOException | ClassNotFoundException error) {
                return false;
            }

            this.nextPersonNumber = loadedData.nextPersonNumber;
            this.listOfPerson = loadedData.listOfPerson;
            this.fileName = loadedData.fileName;

            return true;
	}
        
        private boolean saveInformation(File fileName) {
            try {
                ObjectOutputStream outStream = new ObjectOutputStream(new FileOutputStream(fileName));
                outStream.writeObject(this);
                outStream.close();
            }
            catch(IOException error) {
                return false;
            }
            return true;
	}
        
        public ObservableList<PersonRow> getAllPeople() {
            ObservableList<PersonRow> people = FXCollections.observableArrayList();
            for (Student person : this.listOfPerson.values()) {
            	people.add(person.getPersonRow());
            }
            
            return people;
        }
        
        public ObservableList<PersonRow> getFilteredPeople(String personNumber, String firstName, String lastName, String address, String tel, String classNumber, String login, String password) {
            ObservableList<PersonRow> filteredPerson = FXCollections.observableArrayList();
            for (Student person : this.listOfPerson.values()) {
                if (person.equals(personNumber, firstName, lastName, address, tel, classNumber, login, password)) {
                    filteredPerson.add(person.getPersonRow());
                }
            }
            
            return filteredPerson;
        }
        
        Student getAccount(String accountNumber) {
            return this.listOfPerson.get(accountNumber);
	}
        
        public PersonRow createAccountStudent(String firstName, String lastName, String address, String tel, int classNumber, String login, String password) {
        	Student person = new Student(this.nextPersonNumber++, firstName, lastName, address, tel, classNumber, login, password);
        	listOfPerson.put(Integer.toString(this.nextPersonNumber - 1), person);
            this.saveInformation(this.fileName);
            return person.getPersonRow();
	}
        
        public boolean deleteAccount(String accountNumber) {
            int numberBefore = this.listOfPerson.values().toArray().length;
            this.listOfPerson.remove(accountNumber);
            if (numberBefore != this.listOfPerson.values().toArray().length) {
                this.saveInformation(fileName);
                return true;
            } else {
                return false;
            }
	}
}
