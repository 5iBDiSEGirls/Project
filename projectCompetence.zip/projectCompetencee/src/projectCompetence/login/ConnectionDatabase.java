package projectCompetence.login;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;


public class ConnectionDatabase {

	public Connection Connect() {
		
		try
        {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			 

            String userName ="sa";
            String password = "asia240519947";
            String url = "jdbc:sqlserver://localhost:1433;databasename=school";
            Connection con = DriverManager.getConnection(url, userName, password);
            return con;
            
            
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(ConnectionDatabase.class.getName()).log(Level.SEVERE,null, ex);
        }
		return null;
		

	}

}