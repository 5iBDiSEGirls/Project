package projectCompetence.welcomeTeacher;

import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import projectCompetence.login.ConnectionDatabase;

public class ClassController implements Initializable {
	int numberId;
	public void setId(int numberId) {
		this.numberId = numberId;
	}
	@FXML
	private TableView<User> tableUser;
	@FXML
	private TableColumn<User,String> columnName;
	@FXML
	private TableColumn<User,String> columnLastName;
	
	@FXML
	private TableColumn<User,String> columnEmail;
	
	@FXML
	private Button btnLoad;
	
	
	private ObservableList<User>data;

	private ConnectionDatabase dc;
	

	@Override
	public void initialize(URL url, ResourceBundle rb) {
		
		dc = new ConnectionDatabase();
		
	}
	
	@FXML
	private void LoadDataFromDatabaseeAdres(ActionEvent event){
		try{
		Connection con = dc.Connect();
		data = FXCollections.observableArrayList();
		ResultSet rs=con.createStatement().executeQuery("select imie, nazwisko, _login from pupil order by nazwisko;");
		while(rs.next()){
			data.add(new User(rs.getString("imie"),rs.getString("nazwisko"),rs.getString("_login")));
		}
		
	}catch (SQLException ex){
		System.err.println("Error" + ex);
	}
		
		columnName.setCellValueFactory(new PropertyValueFactory<>("name"));
		columnLastName.setCellValueFactory(new PropertyValueFactory<>("lastName"));
		columnEmail.setCellValueFactory(new PropertyValueFactory<>("email"));

		//tableUser.setItems(null);
		tableUser.setItems(data);
		

}
	@FXML
	private void LoadDataFromDatabasee(ActionEvent event){
		try{
		Connection con = dc.Connect();
		data = FXCollections.observableArrayList();
		ResultSet rs=con.createStatement().executeQuery("select imie, nazwisko from pupil where id_klasy="+numberId+" order by nazwisko;");
		while(rs.next()){
			data.add(new User(rs.getString("imie"),rs.getString("nazwisko")));
		}
		
	}catch (SQLException ex){
		System.err.println("Error" + ex);
	}
		
		columnName.setCellValueFactory(new PropertyValueFactory<>("name"));
		columnLastName.setCellValueFactory(new PropertyValueFactory<>("lastName"));

		//tableUser.setItems(null);
		tableUser.setItems(data);
		

}
}
