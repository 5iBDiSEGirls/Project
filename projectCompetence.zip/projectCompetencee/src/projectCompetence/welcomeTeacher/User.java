package projectCompetence.welcomeTeacher;

import javafx.beans.property.StringProperty;
import javafx.beans.property.SimpleStringProperty;

public class User {
	private StringProperty name;
	private StringProperty lastName;
	private StringProperty email;
	
	public String getEmail() {
		return email.get();
	}
	public void setEmail(String email) {
		this.email = new SimpleStringProperty(email);
	}
	public User(String name, String lastName, String email) {
		this.name = new SimpleStringProperty(name);
		this.lastName = new SimpleStringProperty(lastName);
		this.email = new SimpleStringProperty(email);
	}
	public User(String name, String lastName) {
		this.name = new SimpleStringProperty(name);
		this.lastName = new SimpleStringProperty(lastName);
	}
	
	public String getName() {return name.get();}
	public String getLastName() {return lastName.get();}
	
	public void setName(String value) {
		name.set(value);
	}
	public void setLastName(String value) {
		lastName.set(value);
	}


}

