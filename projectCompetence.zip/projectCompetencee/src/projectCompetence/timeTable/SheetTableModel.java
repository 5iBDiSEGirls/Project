package projectCompetence.timeTable;

import javax.swing.event.TableModelListener;
import javax.swing.table.TableModel;
import jxl.Cell;
import jxl.Sheet;

class SheetTableModel implements TableModel {
    
    private Sheet sheet;
    
    public SheetTableModel(Sheet sheet) {
        this.sheet = sheet;
    }
    
    public int getRowCount() {
        return sheet.getRows();
    }
    
    public int getColumnCount() {
        return sheet.getColumns();
    }
  
   public String getColumnName(int column) {
        String result = "";
        for (; column >= 0; column = column / 26 - 1) {
            result =   result;
        }
        return result;
   }
    
    public Class<?> getColumnClass(int columnIndex) {
        return String.class;
    }
    
    public boolean isCellEditable(int rowIndex, int columnIndex) {
     
        return false;
    }
    
    public Object getValueAt(int rowIndex, int columnIndex) {
        Cell cell = sheet.getCell(columnIndex, rowIndex);
        return cell.getContents();
    }
    
    public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
       
    }
    
    public void addTableModelListener(TableModelListener l) {
      
    }
    
    public void removeTableModelListener(TableModelListener l) {
    
    }
    
} 