package projectCompetence.welcomeTeacher;

import javafx.beans.property.StringProperty;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;

public class User {
	private StringProperty name;
	private StringProperty lastName;
	private StringProperty email;
	private IntegerProperty present;
	private Integer idUcznia;
	
	
	public Integer getIdUcznia() {
		return idUcznia;
	}
	public void setIdUcznia(Integer idUcznia) {
		this.idUcznia = idUcznia;
	}
	public void setPresent(Integer present) {
		this.present = new SimpleIntegerProperty(present);
	}
	public Integer getPresent() {
		return present.get();
	}
	public String getEmail() {
		return email.get();
	}
	public void setEmail(String email) {
		this.email = new SimpleStringProperty(email);
	}
	public User(String name, String lastName, String email) {
		this.name = new SimpleStringProperty(name);
		this.lastName = new SimpleStringProperty(lastName);
		this.email = new SimpleStringProperty(email);
	}
	public User(String name, String lastName, Integer present, Integer idUcznia) {
		this.name = new SimpleStringProperty(name);
		this.lastName = new SimpleStringProperty(lastName);
		this.present = new SimpleIntegerProperty(present);
		this.idUcznia = idUcznia;
	}
	
	public String getName() {return name.get();}
	public String getLastName() {return lastName.get();}
	
	public void setName(String value) {
		name.set(value);
	}
	public void setLastName(String value) {
		lastName.set(value);
	}


}



