package projectCompetence.welcomeTeacher;

import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;

import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableColumn.CellDataFeatures;
import javafx.scene.control.TableColumn.CellEditEvent;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.CheckBoxTableCell;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.util.Callback;
import javafx.util.StringConverter;
import javafx.util.converter.IntegerStringConverter;
import javafx.util.converter.NumberStringConverter;
import projectCompetence.MainApp;


public class ClassController implements Initializable {
	int numberId;
	public void setId(int numberId) {
		this.numberId = numberId;
	}
	@FXML
	private TableView<User> tableUser;
	@FXML
	private TableColumn<User,String> columnName;
	@FXML
	private TableColumn<User,String> columnLastName;
	@FXML
	private TableColumn<User,Integer>  columnPresence;
	
	@FXML
	private TableColumn<User,String> columnEmail;
	
	@FXML
	private Button btnLoad;
	
	@FXML
	private Button btnSave;
	
	@FXML
	private DatePicker dp;
	
	private ObservableList<User>data;
	private LocalDate date;
	

	@Override
	public void initialize(URL url, ResourceBundle rb) {
		
	
		
	}
	@FXML
	private void datePickerAction(ActionEvent event) {
	    date = dp.getValue();
	   
	    System.out.println(date);
	}
	@FXML
	private void LoadDataFromDatabaseeAdres(ActionEvent event) throws ClassNotFoundException{
		try{
		Connection con = MainApp.getConnection();
		data = FXCollections.observableArrayList();
		ResultSet rs=con.createStatement().executeQuery("select imie, nazwisko, _login from pupil order by nazwisko;");
		

		while(rs.next()){
			data.add(new User(rs.getString("imie"),rs.getString("nazwisko"),rs.getString("_login")));
		}
		
	}catch (SQLException ex){
		System.err.println("Error" + ex);
	}
		
		columnName.setCellValueFactory(new PropertyValueFactory<>("name"));
		columnLastName.setCellValueFactory(new PropertyValueFactory<>("lastName"));
		columnEmail.setCellValueFactory(new PropertyValueFactory<>("email"));
		
		
		
		tableUser.setItems(data);
		

}
	@FXML
	private void SaveDataToDatabasee(ActionEvent event) throws ClassNotFoundException{
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			Connection con = DriverManager
					.getConnection("jdbc:sqlserver://project-competence.database.windows.net:1433;"
							+ "database=School;user=BDiSE@project-competence;password=dreamTeam1;encrypt=true;"
							+ "trustServerCertificate=false;hostNameInCertificate=*.database.windows.net;loginTimeout=30;");

			Statement s1 = con.createStatement();
			
			
			
			for(int i = 0; i < data.size(); i++) {
			 String sqlInsert ="insert into presence values('"+date+"',"+"1,"+data.get(i).getIdUcznia()+","+columnPresence.getCellObservableValue(i).getValue()+")"; 
			 s1.executeUpdate(sqlInsert);
			}
			

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
		
	@FXML
	private void LoadDataFromDatabasee(ActionEvent event) throws ClassNotFoundException{
		try{
		Connection con = MainApp.getConnection();
		
		data = FXCollections.observableArrayList();
		ResultSet rs=con.createStatement().executeQuery("select imie, nazwisko,id_ucznia from pupil where id_klasy="+numberId+" order by nazwisko;");
		while(rs.next()){
			data.add(new User(rs.getString("imie"),rs.getString("nazwisko"),0,rs.getInt("id_ucznia")));
		}
		
	}catch (SQLException ex){
		System.err.println("Error" + ex);
	}
		
		columnName.setCellValueFactory(new PropertyValueFactory<>("name"));
		columnLastName.setCellValueFactory(new PropertyValueFactory<>("lastName"));
		columnPresence.setCellValueFactory(new PropertyValueFactory<>("present"));
		columnPresence.setCellFactory((TextFieldTableCell.forTableColumn(new StringConverter<Integer>(){

	        @Override
	        public String toString(Integer object) {
	            return object.toString();
	        }

	        @Override
	        public Integer fromString(String string) {
	            return Integer.parseInt(string);
	        }

	    })));
		columnPresence.setOnEditCommit(
			    new EventHandler<CellEditEvent<User, Integer>>() {
			        @Override
			        public void handle(CellEditEvent<User, Integer> t) {
			            ((User) t.getTableView().getItems().get(
			                t.getTablePosition().getRow())
			                ).setPresent(t.getNewValue());
			        }
			    }
			);
		tableUser.setEditable(true);
		tableUser.setItems(data);
		

}
}
