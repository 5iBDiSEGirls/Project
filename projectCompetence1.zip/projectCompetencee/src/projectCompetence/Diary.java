package projectCompetence;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.*;
import java.io.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import projectCompetence.Student.PersonRow;

public class Diary implements Serializable {
	
	private int nextPersonNumber;
	private Map<String, Student> listOfPerson;
	
	public Diary(String diaryName) throws ClassNotFoundException, SQLException {
		if (!this.loadInformation()) {
			this.nextPersonNumber = 1;
			this.listOfPerson = new HashMap<>();
		}
	}
	
	private boolean loadInformation() throws ClassNotFoundException, SQLException {
		Diary loadedData = null;
		Statement s1 = MainApp.getStatement() ;
		ResultSet rs = s1.executeQuery("SELECT * from pupil");
		String result = "";
		
		this.nextPersonNumber = (int) resultSetToArrayList(rs).get(nextPersonNumber);
		this.listOfPerson = resultSetToArrayList(rs);
		
		return true;
	}
        
    public Map resultSetToArrayList(ResultSet rs) throws SQLException{
    	  ResultSetMetaData md = rs.getMetaData();
    	  int columns = md.getColumnCount();
    	  while (rs.next()){
    	     for(int i=1; i<=columns; ++i){           
    	    	 listOfPerson.put(md.getColumnName(i),(Student) rs.getObject(i));
    	     }
    	  }

    	 return listOfPerson;
    	}

	public ObservableList<PersonRow> getAllPeople() {
        ObservableList<PersonRow> people = FXCollections.observableArrayList();
        for (Student person : this.listOfPerson.values()) {
        	people.add(person.getPersonRow());
        }
        
        return people;
    }
        
    public ObservableList<PersonRow> getFilteredPeople(String personNumber, String firstName, String lastName, String address, String tel, String classNumber, String login, String password) {
        ObservableList<PersonRow> filteredPerson = FXCollections.observableArrayList();
        for (Student person : this.listOfPerson.values()) {
            if (person.equals(personNumber, firstName, lastName, address, tel, classNumber, login, password)) {
                filteredPerson.add(person.getPersonRow());
            }
        }
        
        return filteredPerson;
    }
    
    Student getAccount(String accountNumber) {
        return this.listOfPerson.get(accountNumber);
    }
        
    public PersonRow createAccountStudent(String firstName, String lastName, String address, String tel, int classNumber, String login, String password) throws ClassNotFoundException, SQLException {
    	Student person = new Student(this.nextPersonNumber++, firstName, lastName, address, tel, classNumber, login, password);
    	listOfPerson.put(Integer.toString(this.nextPersonNumber - 1), person);
    	Statement s1 = MainApp.getStatement();
    	
    	//TODO
    	
    	String sqlInsert = "insert into pupil values(118, 'Karolina', 'Nowacka', 'ul.Wigury 77, 35-907 ��d�', '609566867', 6, 'knowacka@uczen.pl', 'KhyR2Fcl')"; 
    	s1.executeUpdate(sqlInsert);
        return person.getPersonRow();
    }
        
    public boolean deleteAccount(String accountNumber) throws ClassNotFoundException, SQLException {
        int numberBefore = this.listOfPerson.values().toArray().length;
        this.listOfPerson.remove(accountNumber);
        if (numberBefore != this.listOfPerson.values().toArray().length) {
        	Statement s1 = MainApp.getStatement();
        	
        	//TODO
        	
        	String sqlDelete = "delete * pupil where imie like 'Karolina' and nazwisko like 'Nowacka'"; 
        	s1.executeUpdate(sqlDelete);
            return true;
        } else {
            return false;
        }
    }
}
