package projectCompetence;

import java.io.IOException;
import java.util.Optional;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonBar.ButtonData;
import javafx.stage.Stage;
import projectCompetence.login.LoginController;
import projectCompetence.welcomeTeacher.TeacherController;

public class MainApp extends Application {    

	//TeacherController controllerT;
	//LoginController controller;
	private Stage stage;
	
    @Override
    public void start(Stage stage) throws Exception{
    	this.stage = stage;
    	loadStage();
		stage.show();
    }
    
    public void loadStage() throws IOException {
    	FXMLLoader loader = new FXMLLoader();
    	loader.setLocation(getClass().getResource("login/LoginScene.fxml"));
    	Parent root = loader.load();
		Scene scene = new Scene(root);
		stage.setScene(scene);
		stage.setTitle("Logowanie w Leggo");
		((LoginController) loader.getController()).setMainApp(this);
    }
    
    public static boolean showQuestionDialog(String title, String headerText, String contentText) {
        Alert alert = new Alert(AlertType.CONFIRMATION);
        alert.setTitle(title);
        alert.setHeaderText(headerText);
        alert.setContentText(contentText);
        
        Optional<ButtonType> result = alert.showAndWait();
        return result.isPresent() && result.get().getButtonData() == ButtonData.OK_DONE;
    }

    public static void main(String[] args) {
        launch(args);
    }

	public Stage getStage() {
		return stage;
	}
}
