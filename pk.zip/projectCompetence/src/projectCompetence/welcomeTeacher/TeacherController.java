package projectCompetence.welcomeTeacher;

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import projectCompetence.MainApp;


public class TeacherController {

	private MainApp mainApp;
	
	private static AnchorPane rootLayout;
	
	/*public void initRootLayout() {
        try {
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("welcomeTeacher/RootLayout.fxml"));
            rootLayout = loader.load();
            Scene scene = new Scene(rootLayout);
            stage.setScene(scene);
            stage.setTitle("Zalogowany jako nauczyciel");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }*/
	/* @FXML
    public void showLogoutScene(){
    	try{
    	
    	FXMLLoader loader = new FXMLLoader();
    	loader.setLocation(MainApp.class.getResource("welcomeTeacher/Logout.fxml"));
    	AnchorPane logout = loader.load();
    	
    	rootLayout.getChildren().add(logout);
    	
    	} catch (IOException e) {
            e.printStackTrace();
        }
    	
    }*/
	@FXML
	private void LogoutButtonAction(ActionEvent event) throws Exception{
		if(MainApp.showQuestionDialog("Potwierdzenie", "Czy napewno chcesz sie wylogowa�?", "")) {
			mainApp.loadStage();
		}
	}

	public static void showTeacher(MainApp mainApp) {
		try {
		  	
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(MainApp.class.getResource("welcomeTeacher/Teacher.fxml"));
			rootLayout = loader.load();
			((TeacherController) loader.getController()).setMainApp(mainApp);
			Scene scene = new Scene(rootLayout);
			mainApp.getStage().setScene(scene);
			mainApp.getStage().setTitle("Nauczyciel");
		} catch (IOException e) {
		    e.printStackTrace();
		}
}

	private void setMainApp(MainApp mainApp) {
		this.mainApp = mainApp;
		
	}
}
