package projectCompetence.welcomeStudent;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.TextArea;
import javafx.scene.layout.AnchorPane;
import projectCompetence.MainApp;
import projectCompetence.welcomeAdmin.AdminController;

public class StudentController {

	@FXML
	
	TextArea sNews;
	
	private MainApp mainApp;
	
	private static AnchorPane rootLayout;
	@FXML
	private void LogoutButtonAction(ActionEvent event) throws Exception{
		if(MainApp.showQuestionDialog("Potwierdzenie", "Czy napewno chcesz sie wylogowa�?", "")) {
			mainApp.loadStage();
		}
	}
	
	private void loadNews() throws ClassNotFoundException, SQLException {
		
		Statement s1 = MainApp.getStatement();
		ResultSet rs = s1.executeQuery("select * from news order by dateNews DESC");
		while (rs.next()) {
			sNews.setText(sNews.getText() + rs.getString("dateNews") + "\n" + rs.getString("news") + "\n\n");
		}	
	}
	
	public static void showStudent(MainApp mainApp) {
		try {
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(MainApp.class.getResource("welcomeStudent/Student.fxml"));
			rootLayout = loader.load();
			((StudentController) loader.getController()).setMainApp(mainApp);
			Scene scene = new Scene(rootLayout);
			mainApp.getStage().setScene(scene);
			mainApp.getStage().setTitle("Uczen");
		} catch (IOException e) {
		    e.printStackTrace();
		}
}
	private void setMainApp(MainApp mainApp) {
		this.mainApp = mainApp;
	}
	
	@FXML
	private void initialize() throws ClassNotFoundException, SQLException {
		loadNews();
	}
}
