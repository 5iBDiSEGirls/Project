package projectCompetence;

import java.io.*;
import javafx.beans.property.SimpleStringProperty;

@SuppressWarnings("serial")
public class Student implements Serializable {
	
    private final int personNumber;
    private final String firstName;
    private final String lastName;
    private final String address;
    private final String tel;
    private final int classNumber;
    private final String login;
    private final String password;

    Student(int personNumber, String firstName, String lastName, String address, String tel, int classNumber, String login, String password) {
        this.personNumber = personNumber;
        this.firstName = firstName;
        this.lastName = lastName;
        this.address = address;
        this.tel = tel;
        this.classNumber = classNumber;
        this.login = login;
        this.password = password;
    }

    public boolean equals(String personNumber, String firstName, String lastName, String address, String tel, String classNumber, String login) {
        return ("".equals(personNumber) ||personNumber.equals(String.valueOf(this.personNumber))) &&
            ("".equals(firstName) || this.firstName.contains(firstName))  && 
            ("".equals(lastName) || this.lastName.contains(lastName)) &&
            ("".equals(address) || this.address.contains(address)) &&
            ("".equals(tel) || this.tel.contains(tel)) &&
            ("".equals(classNumber) ||classNumber.equals(String.valueOf(this.classNumber))) &&
            ("".equals(login) || this.login.contains(login));
    }

    public int getPersonNumber() {
		return personNumber;
	}

	public String getFirstName() {
		return firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public String getAddress() {
		return address;
	}

	public String getTel() {
		return tel;
	}

	public int getClassNumber() {
		return classNumber;
	}

	public String getLogin() {
		return login;
	}

	public String getPassword() {
		return password;
	}

	public PersonRow getPersonRow() {
        return new PersonRow(String.valueOf(personNumber),
							firstName,
							lastName,
							address,
							tel,
							String.valueOf(classNumber),
							login,
							password);
    }
	
	public String getSQLData() {
		return Integer.toString(this.personNumber) + ", '" + 
				this.firstName + "', '" +
				this.lastName + "', '" +
				this.address + "', '" +
				this.tel + "', " + 
				this.classNumber + ", '" +
				this.login + "', '" +
				this.password + "'";
	}
    
    public class PersonRow {
    
        private final SimpleStringProperty personNumber;
        private final SimpleStringProperty firstName;
        private final SimpleStringProperty lastName;
        private final SimpleStringProperty address;
		private final SimpleStringProperty tel;
        private final SimpleStringProperty classNumber;
        private final SimpleStringProperty login;
		private final SimpleStringProperty password;


        private PersonRow(String pNumber, String fName, String lName, String cAddress, String ptel, String pclassNumber, String plogin, String ppassword) {
            this.personNumber = new SimpleStringProperty(pNumber);
            this.firstName = new SimpleStringProperty(fName);
            this.lastName = new SimpleStringProperty(lName);
            this.address = new SimpleStringProperty(cAddress);
            this.tel = new SimpleStringProperty(ptel);
            this.classNumber = new SimpleStringProperty(pclassNumber);
            this.login = new SimpleStringProperty(plogin);
            this.password = new SimpleStringProperty(ppassword);
        }

        public String getPersonNumber() {
            return personNumber.get();
        }

        public String getFirstName() {
            return firstName.get();
        }

        public String getLastName() {
            return lastName.get();
        }
        
        public String getAddress() {
            return address.get();
        }
        
        public String getTel() {
            return tel.get();
        }
        
        public String getClassNumber() {
            return classNumber.get();
        }

        public String getLogin() {
            return login.get();
        }
        
        public String getPassword() {
            return password.get();
        }
    }
}
	

