package projectCompetence.welcomeStudent;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.ResourceBundle;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.font.PDType1Font;

import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.MenuButton;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TablePosition;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.CheckBoxTableCell;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.util.Callback;
import projectCompetence.MainApp;
import projectCompetence.welcomeTeacher.User;


public class ClassController implements Initializable {
	int numberId;
	public void setId(int numberId) {
		this.numberId = numberId;
		
	}
	String selectedMenuItem;
	HashMap<String,Integer> subject = new HashMap<String,Integer>();
	@FXML
	private TableView<User> tableUser;
	@FXML
	private TableColumn<User,String> columnName;
	@FXML
	private TableColumn<User,String> columnLastName;
	@FXML
	private TableColumn<User,String> columnEmail;

	@FXML 
	private MenuButton menuButton; 
	
	@FXML
	private Button btnSave;
	
	@FXML
	private Button btnGenerateReport;
	
	@FXML
	private DatePicker dp;
	
	private ObservableList<User>data;
	private LocalDate date;
	
	

	@Override
	public void initialize(URL url, ResourceBundle rb) {
		
	}
	@FXML
	private void datePickerAction(ActionEvent event) {
	    date = dp.getValue();

	}
	public void LoadDataFromDatabaseeAdres(String select) throws ClassNotFoundException{
		try{
		Connection con = MainApp.getConnection();
		data = FXCollections.observableArrayList();
		ResultSet rs=con.createStatement().executeQuery("select imie, nazwisko, _login from "+select+" order by nazwisko;");
		

		while(rs.next()){
			data.add(new User(rs.getString("imie"),rs.getString("nazwisko"),rs.getString("_login")));
		}
		
	}catch (SQLException ex){
		System.err.println("Error" + ex);
	}
		
		columnName.setCellValueFactory(new PropertyValueFactory<>("name"));
		columnLastName.setCellValueFactory(new PropertyValueFactory<>("lastName"));
		columnEmail.setCellValueFactory(new PropertyValueFactory<>("email"));
		
		
		
		tableUser.setItems(data);
		

}
	@FXML
	private void SaveDataToDatabasee(ActionEvent event) throws ClassNotFoundException{
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			Connection con = DriverManager
					.getConnection("jdbc:sqlserver://project-competence.database.windows.net:1433;"
							+ "database=School;user=BDiSE@project-competence;password=dreamTeam1;encrypt=true;"
							+ "trustServerCertificate=false;hostNameInCertificate=*.database.windows.net;loginTimeout=30;");

			Statement s1 = con.createStatement();
			
			
			
			for(int i = 0; i < data.size(); i++) {
			 String sqlInsert ="insert into presence values('"+date+"',"+subject.get(selectedMenuItem)+","+data.get(i).getIdUcznia()+","+data.get(i).getPresent()+")"; 
			 s1.executeUpdate(sqlInsert);
			}
			

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public void addListeners() {
		ObservableList<MenuItem> items = menuButton.getItems();
		for(MenuItem item: items) {
		item.setOnAction(event -> {
		    selectedMenuItem = item.getText();
		    menuButton.setText(item.getText());
		});
		}
	}
	
}
