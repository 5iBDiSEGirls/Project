package projectCompetence.welcomeStudent;

import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;

import javax.swing.JOptionPane;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import projectCompetence.MainApp;
import projectCompetence.timeTable.openSchedule;
import projectCompetence.welcomeTeacher.*;

public class StudentController {

	@FXML
	
	TextArea sNews;
	
	private MainApp mainApp;
	static File file;
	private static AnchorPane rootLayout;
	@FXML
	private void LogoutButtonAction(ActionEvent event) throws Exception{
		if(MainApp.showQuestionDialog("Potwierdzenie", "Czy napewno chcesz sie wylogowa�?", "")) {
			mainApp.loadStage();
		}
	}
	@FXML
	private void goTo1aButtonAction(ActionEvent event) throws Exception{
		file = openSchedule.createFile(0);
		openSchedule.runWindow();
	}
	
	public static File getFile() {
		return file;
	}

	@FXML
	private void goTo1bButtonAction(ActionEvent event) throws Exception{
		file = openSchedule.createFile(1);
		openSchedule.runWindow();
	}
	
	@FXML
	private void goTo2aButtonAction(ActionEvent event) throws Exception{
		file = openSchedule.createFile(2);
		openSchedule.runWindow();
	}
	
	@FXML
	private void goTo2bButtonAction(ActionEvent event) throws Exception{
		file = openSchedule.createFile(3);
		openSchedule.runWindow();
	}
	
	@FXML
	private void goTo3aButtonAction(ActionEvent event) throws Exception{
		file = openSchedule.createFile(4);
		openSchedule.runWindow();
	}
	
	@FXML
	private void goTo3bButtonAction(ActionEvent event) throws Exception{
		file = openSchedule.createFile(5);
		openSchedule.runWindow();
	}
	private void loadNews() throws ClassNotFoundException, SQLException {
		
		Statement s1 = MainApp.getStatement();
		ResultSet rs = s1.executeQuery("select * from news order by dateNews DESC");
		while (rs.next()) {
			sNews.setText(sNews.getText() + rs.getString("dateNews") + "\n" + rs.getString("news") + "\n\n");
		}	
	}
	
	public static void showStudent(MainApp mainApp, ResultSet result) throws SQLException {
		try {
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(MainApp.class.getResource("welcomeStudent/Student.fxml"));
			rootLayout = loader.load();
			((StudentController) loader.getController()).setMainApp(mainApp);
			Scene scene = new Scene(rootLayout);
			result.next();
			mainApp.getStage().setScene(scene);
			mainApp.getStage().setTitle(result.getString("imie")+result.getString("nazwisko"));
		} catch (IOException e) {
		    e.printStackTrace();
		}
}
	@FXML
	private TableView<User> tableUser;
	@FXML
	private TableColumn<User,String> columnName;
	@FXML
	private TableColumn<User,String> columnLastName;
	@FXML
	private TableColumn<User,String> columnEmail;
	private ObservableList<User>data;
	//private LocalDate date;
	
	 @FXML
		private Button Adres;
	   @FXML
	   private void goAddress(ActionEvent event){
		   try{
			   FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("Addres.fxml"));
			   Parent root1 = (Parent) fxmlLoader.load();
			   ClassController controllerr = fxmlLoader.getController();
			   controllerr.LoadDataFromDatabaseeAdres("teacher");
			   Stage stage = new Stage();
			   stage.setTitle("Adres");
			   stage.setScene(new Scene(root1));
			   stage.show();
			  // mainApp.getStage().setResizable(false);
			   
			   
		   }catch(Exception e) {
			   e.printStackTrace();
			   System.out.println("Nie mozna zaladowac okna Adresu");
		   }
		   
	   }
	  @FXML TextField address;
	  @FXML TextField subject;
	  @FXML TextArea message;
	  @FXML Button Wyslij;
	   @FXML 
	   private void sendMessage(ActionEvent event) {
		   try{
		   if(address.getText()!= null && !address.getText().equals("")){
			   Email email = new Email(address.getText(),subject.getText(), message.getText());
			   address.setText("");
			   subject.setText("");
			   message.setText("");
			   
			   System.out.println("dziala");
		   }else {
			   JOptionPane.showMessageDialog(null,"Nie uzupe�ni�e� pola","Error", JOptionPane.OK_OPTION);
			  
		 }
		   
	   }catch(Exception e){
	   }
	   }
	private void setMainApp(MainApp mainApp) {
		this.mainApp = mainApp;
	}
	
	@FXML
	private void initialize() throws ClassNotFoundException, SQLException {
		//loadNews();
	}
}
