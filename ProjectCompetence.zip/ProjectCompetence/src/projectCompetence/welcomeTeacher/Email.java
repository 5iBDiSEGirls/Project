package projectCompetence.welcomeTeacher;

import java.util.Properties;

import javax.mail.Message;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class Email {
		public Email(String address, String subject, String message) {
			Properties prop = System.getProperties();
			prop.put("mail.smtp.starttls.enable", "true");
			prop.put("mail.smtp.host", "smtp.gmail.com");
			prop.put("mail.smtp.user", "fromtestemail@gmail.com");
			prop.put("mail.smtp.password", "12345test");
			prop.put("mail.smtp.port", "587");
			prop.put("mail.smtp.auth", "true");
			Session session = Session.getDefaultInstance(prop, null);
			MimeMessage mime = new MimeMessage(session);
		try{
			InternetAddress to = new InternetAddress(address);
			InternetAddress from = new InternetAddress("fromtestemail@gmail.com");
			mime.addRecipient(Message.RecipientType.TO, to);
			mime.setFrom(from);
			mime.setSubject(subject);
			mime.setText(message);
			Transport t = session.getTransport("smtp");
			t.connect("smtp.gmail.com", "fromtestemail@gmail.com", "12345test");
			t.sendMessage(mime, mime.getAllRecipients());
			t.close();
			System.out.println("Mail has been sent");
			
		}catch(Exception ee){
			ee.printStackTrace();
		}
		}

}
