
package projectCompetence.welcomeTeacher;

import java.io.File;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import javax.swing.JOptionPane;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import projectCompetence.MainApp;
import projectCompetence.login.LoginController;
import projectCompetence.timeTable.TeacherTimeTable;
import projectCompetence.timeTable.openSchedule;
import projectCompetence.welcomeAdmin.TimeTableEdit;


public class TeacherController {

	private MainApp mainApp;
	private static AnchorPane rootLayout;
	static File file;
	@FXML
	TextArea news;
	@FXML
	TextArea addNews;

	@FXML
	private void LogoutButtonAction(ActionEvent event) throws Exception{
		if(MainApp.showQuestionDialog("Potwierdzenie", "Czy napewno chcesz sie wylogowa�?", "")) {
			mainApp.loadStage();
		}
	}

	@FXML
	private void goTo1aButtonAction(ActionEvent event) throws Exception{
		file = openSchedule.createFile(0);
		openSchedule.runWindow();
	}
	
	public static File getFile() {
		return file;
	}

	@FXML
	private void goTo1bButtonAction(ActionEvent event) throws Exception{
		file = openSchedule.createFile(1);
		openSchedule.runWindow();
	}
	
	@FXML
	private void goTo2aButtonAction(ActionEvent event) throws Exception{
		file = openSchedule.createFile(2);
		openSchedule.runWindow();
	}
	
	@FXML
	private void goTo2bButtonAction(ActionEvent event) throws Exception{
		file = openSchedule.createFile(3);
		openSchedule.runWindow();
	}
	
	@FXML
	private void goTo3aButtonAction(ActionEvent event) throws Exception{
		file = openSchedule.createFile(4);
		openSchedule.runWindow();
	}
	
	@FXML
	private void goTo3bButtonAction(ActionEvent event) throws Exception{
		file = openSchedule.createFile(5);
		openSchedule.runWindow();
	}
	@FXML
	private void planButtonActionT() throws Exception{
		TeacherTimeTable plan = new TeacherTimeTable();
		plan.show();
	}
	public static void showTeacher(MainApp mainApp,ResultSet result) throws SQLException {
		try {
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(MainApp.class.getResource("welcomeTeacher/Teacher.fxml"));
			rootLayout = loader.load();
			((TeacherController) loader.getController()).setMainApp(mainApp);
			Scene scene = new Scene(rootLayout);
			mainApp.getStage().setScene(scene);
			result.next();
			mainApp.getStage().setTitle(result.getString("imie")+" "+result.getString("nazwisko"));
			//mainApp.getStage().setResizable(false);
		} catch (IOException e) {
		    e.printStackTrace();
		}
}
	@FXML
	private MenuItem menu1;
	@FXML
	private MenuItem menu2;
	@FXML
	private MenuItem menu3;
	@FXML
	private MenuItem menu4;
	@FXML
	private MenuItem menu5;
	@FXML
	private MenuItem menu6;
	   @FXML
	   private void goClass(ActionEvent event){
		   try{
			   FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("Class.fxml"));
			   Parent root1 = (Parent) fxmlLoader.load();
			   Stage stage = new Stage();
			   ClassController controller = fxmlLoader.<ClassController>getController();
			   if(event.getSource()==menu1){
				   controller.setId(1);
			   		controller.setData();
			   }
			   else if(event.getSource()==menu2){
				   controller.setId(2);
				controller.setData();
		   }
			   else if(event.getSource()==menu3){
				   controller.setId(3);
				controller.setData();
	   }
			   else if(event.getSource()==menu4){
				   controller.setId(4);
				controller.setData();
}
			   else if(event.getSource()==menu5){
				   controller.setId(5);
				controller.setData();
			   }
			   else if(event.getSource()==menu6){
				   controller.setId(6);
				controller.setData();
			   }
			   stage.setTitle("Klasa");
			   stage.setScene(new Scene(root1));
			   stage.show();
			   
			   
		   }catch(Exception e) {
			   System.out.println("Nie mozna zaladowac okna Klasy");
		   }
		   
	   }
	   
	   @FXML
	 		private Button Adres;
	 	   @FXML
	 	   private void goAddress(ActionEvent event){
	 		   try{
	 			   FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("Address.fxml"));
	 			   Parent root1 = (Parent) fxmlLoader.load();
	 			   ClassController controller = fxmlLoader.getController();
	 			   controller.LoadDataFromDatabaseeAdres("pupil");
	 			   Stage stage = new Stage();
	 			   stage.setTitle("Adres");
	 			   stage.setScene(new Scene(root1));
	 			   stage.show();
	 			   mainApp.getStage().setResizable(false);
	 			   
	 			   
	 		   }catch(Exception e) {
	 			   e.printStackTrace();
	 			   System.out.println("Nie mozna zaladowac okna Adresu");
	 		   }
	 		   
	 	   }
	  
	   @FXML TextField address;
		  @FXML TextField subject;
		  @FXML TextArea message;
		  @FXML Button Wyslij;
		   @FXML 
		   private void sendMessage(ActionEvent event) {
			   try{
			   if(address.getText()!= null && !address.getText().equals("")){
				   Email email = new Email(address.getText(),subject.getText(), message.getText());
				   address.setText("");
				   subject.setText("");
				   message.setText("");
				   
				   System.out.println("dziala");
			   }else {
				   JOptionPane.showMessageDialog(null,"Nie uzupe�ni�e� pola","Error", JOptionPane.OK_OPTION);
				  
			 }
			   
		   }catch(Exception e){
		   }
		   }
	   
	@FXML
	private void newsButtonAction() throws ClassNotFoundException, SQLException {
		Statement s1 = MainApp.getStatement();
		if(MainApp.showQuestionDialog("Potwierdzenie", "Czy napewno chcesz doda� nowy post?", "")) {
	    	String sqlInsert = "insert into news(news) values('" + addNews.getText() + "')"; 
	    	s1.executeUpdate(sqlInsert);
	    	MainApp.showInformation("Dodawanie aktualno�ci", "Post zosta� dodany.", Alert.AlertType.INFORMATION);
		}
	}
	
	private void loadNews() throws ClassNotFoundException, SQLException {
		
		Statement s1 = MainApp.getStatement();
		ResultSet rs = s1.executeQuery("select * from news order by dateNews DESC");
		while (rs.next()) {
			news.setText(news.getText() + rs.getString("dateNews") + "\n" + rs.getString("news") + "\n\n");
		}	
	}
	
	@FXML
	private void initialize() throws ClassNotFoundException, SQLException {
		loadNews();
	}

	private void setMainApp(MainApp mainApp) {
		this.mainApp = mainApp;
		
	}
}
