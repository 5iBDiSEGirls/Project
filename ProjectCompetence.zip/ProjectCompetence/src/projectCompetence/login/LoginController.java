package projectCompetence.login;

import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import projectCompetence.MainApp;
import projectCompetence.welcomeAdmin.AdminController;
import projectCompetence.welcomeStudent.StudentController;
import projectCompetence.welcomeTeacher.TeacherController;

public class LoginController implements Initializable{

	@FXML
	private Label logLab;
	@FXML
	private TextField textLogin;
	@FXML
	private PasswordField textHaslo;
	
	private MainApp mainApp;
	
	ResultSet result;
	
	@FXML
	private void loginButtonAction(ActionEvent event) throws Exception{
		checkLoginSQL();
		/*if(textLogin.getText().equals("nazwisko@leggo.com") && textHaslo.getText().equals("test")) {
			logLab.setText("Witaj " + textLogin.getText() + "!");
			TeacherController.showTeacher(mainApp);
		}
		else if(textLogin.getText().equals("nazwisko@leggo.com") && textHaslo.getText().equals("test2")) {
			logLab.setText("Witaj " + textLogin.getText() + "!");
			StudentController.showStudent(mainApp);
		}
		else if(textLogin.getText().equals("nazwisko@leggo.com") && textHaslo.getText().equals("test3")) {
			logLab.setText("Witaj " + textLogin.getText() + "!");
			AdminController.showAdmin(mainApp);
		}
		else {
			logLab.setText("Has�o nieprawid�owe!");
		}*/
	}
	
	private void checkLoginSQL() throws ClassNotFoundException, SQLException {
		
		Statement s1 = MainApp.getStatement();
		String login = textLogin.getText();
		
		if(login.toLowerCase().contains("@nauczyciel.pl".toLowerCase())) {
			ResultSet rs = s1.executeQuery("SELECT _login, _password from teacher where _login like '" + textLogin.getText() + "'");
			if (rs.next()) {
				if(textLogin.getText().equals(rs.getString("_login").replaceAll(" ", "")) &&  textHaslo.getText().equals(rs.getString("_password").replaceAll(" ", ""))) {
					logLab.setText("Witaj " + textLogin.getText() + "!");
					result = s1.executeQuery("SELECT * from teacher where _login like '" + textLogin.getText() + "'");
					TeacherController.showTeacher(mainApp,result);
				}
				else {
					logLab.setText("Has�o lub login nieprawid�owe!");
				}
			} else {
				logLab.setText("Has�o lub login nieprawid�owe!");
			}
		}
		else if(login.toLowerCase().contains("@uczen.pl".toLowerCase())) {
			ResultSet rs = s1.executeQuery("SELECT _login, _password from pupil where _login like '" + textLogin.getText() + "'");
			if (rs.next()) {
				if(textLogin.getText().equals(rs.getString("_login").replaceAll(" ", "")) &&  textHaslo.getText().equals(rs.getString("_password").replaceAll(" ", ""))) {
					logLab.setText("Witaj " + textLogin.getText() + "!");
					result = s1.executeQuery("SELECT * from pupil where _login like '" + textLogin.getText() + "'");
					StudentController.showStudent(mainApp,result);
				}
				else {
					logLab.setText("Has�o lub login nieprawid�owe!");
				}
			} else {
				logLab.setText("Has�o lub login nieprawid�owe!");
			}
		}
		else if(login.toLowerCase().contains("@admin.pl".toLowerCase())) {
			ResultSet rs = s1.executeQuery("SELECT _login, _password from admin where _login like '" + textLogin.getText() + "'");
			if (rs.next()) {
				if(textLogin.getText().equals(rs.getString("_login").replaceAll(" ", "")) &&  textHaslo.getText().equals(rs.getString("_password").replaceAll(" ", ""))) {
					logLab.setText("Witaj " + textLogin.getText() + "!");
					result = s1.executeQuery("SELECT * from admin where _login like '" + textLogin.getText() + "'");
					AdminController.showAdmin(mainApp);
				}
				else {
					logLab.setText("Has�o lub login nieprawid�owe!");
				}
			} else {
				logLab.setText("Has�o lub login nieprawid�owe!");
			}
		}
		else {
			logLab.setText("Has�o lub login nieprawid�owe!");
		}
	}
	
	//Odwo�ujcie si� do tego, aby rozr�nia� osoby
	private ResultSet getResultSet(String string) {
		return this.result;
		
	}

	@Override
	public void initialize(URL url, ResourceBundle rb) {
		// TODO Auto-generated method stub
		
	}

	public void setMainApp(MainApp mainApp) {
		this.mainApp = mainApp;
		
	}

}
