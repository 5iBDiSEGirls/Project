package projectCompetence.welcomeAdmin;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JOptionPane;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import projectCompetence.MainApp;
import projectCompetence.welcomeTeacher.Email;

public class AdminController {
	
	@FXML
	TextArea news;
	@FXML
	TextArea addNews;

	private MainApp mainApp;
	
	private static AnchorPane rootLayout;

	@FXML
	private void LogoutButtonAction(ActionEvent event) throws Exception{
		if(MainApp.showQuestionDialog("Potwierdzenie", "Czy napewno chcesz sie wylogowa�?", "")) {
			mainApp.loadStage();
		}
	}
	
	@FXML
	private void studentsButtonAction() throws Exception{
		StudentEditController sec = new StudentEditController();
		sec.show();
	}
	
	@FXML
	private void teacherButtonAction() throws Exception{
		TeacherEditController tec = new TeacherEditController();
		tec.show();
	}


	@FXML
	private void planButtonAction() throws Exception{
		TimeTableEdit pl = new TimeTableEdit();
		pl.show();
	}

	@FXML
	private void newsButtonAction() throws ClassNotFoundException, SQLException {
		Statement s1 = MainApp.getStatement();
		if(MainApp.showQuestionDialog("Potwierdzenie", "Czy napewno chcesz doda� nowy post?", "")) {
	    	String sqlInsert = "insert into news(news) values('" + addNews.getText() + "')"; 
	    	s1.executeUpdate(sqlInsert);
	    	MainApp.showInformation("Dodawanie aktualno�ci", "Post zosta� dodany.", Alert.AlertType.INFORMATION);
		}
	}
	
	private void loadNews() throws ClassNotFoundException, SQLException {
		
		Statement s1 = MainApp.getStatement();
		ResultSet rs = s1.executeQuery("select * from news order by dateNews DESC");
		while (rs.next()) {
			news.setText(news.getText() + rs.getString("dateNews") + "\n" + rs.getString("news") + "\n\n");
		}	
	}

	public static void showAdmin(MainApp mainApp) {
		try {
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(MainApp.class.getResource("welcomeAdmin/Admin.fxml"));
			rootLayout = loader.load();
			((AdminController) loader.getController()).setMainApp(mainApp);
			Scene scene = new Scene(rootLayout);
			mainApp.getStage().setScene(scene);
			//mainApp.getStage().setResizable(false);
			mainApp.getStage().setTitle("Administrator");
		} catch (IOException e) {
		    e.printStackTrace();
		}
}
	  @FXML TextField address;
	  @FXML TextField subject;
	  @FXML TextArea message;
	  @FXML Button Wyslij;
	   @FXML 
	   private void sendMessage(ActionEvent event) {
		   try{
		   if(address.getText()!= null && !address.getText().equals("")){
			   Email email = new Email(address.getText(),subject.getText(), message.getText());
			   address.setText("");
			   subject.setText("");
			   message.setText("");
			   
			   System.out.println("dziala");
		   }else {
			   JOptionPane.showMessageDialog(null,"Nie uzupe�ni�e� pola","Error", JOptionPane.OK_OPTION);
			  
		 }
		   
	   }catch(Exception e){
	   }
	   }
	@FXML
	private void initialize() throws ClassNotFoundException, SQLException {
		loadNews();
	}

	private void setMainApp(MainApp mainApp) {
		this.mainApp = mainApp;
	}
}
