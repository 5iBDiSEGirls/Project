package projectCompetence.welcomeTeacher;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.font.PDType1Font;

import javafx.scene.control.Alert;
import javafx.scene.control.TablePosition;
import projectCompetence.MainApp;

public class Reports {

	public void generateGradesReport(TablePosition pos, User user)
			throws IOException, ClassNotFoundException, SQLException {
		int i = 0;
		DecimalFormat df = new DecimalFormat("#.##");

		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd");
		LocalDate localDate = LocalDate.now();
		String imie = user.getName().get().replaceAll(" ", "");
		String nazwisko = user.getLastName().get().replaceAll(" ", "");
		Integer idUcznia = user.getIdUcznia();

		String fileName = imie + nazwisko + "_" + "GradesReport" + ".pdf";
		fileName.replace(" ", "");
		PDDocument doc = new PDDocument();
		PDPage page = new PDPage();
		doc.addPage(page);

		PDPageContentStream contentStream = new PDPageContentStream(doc, page);
		contentStream.beginText();

		contentStream.setLeading(23);
		contentStream.newLineAtOffset(25, 725);

		String text1 = "Raport Ocen";
		String text2 = "Imie: " + imie;
		String text3 = "Nazwisko: " + nazwisko;
		String text4 = "ID Ucznia: " + idUcznia.toString();
		String text5 = "Data : " + dtf.format(localDate);
		String text6 = "ID";
		String text7 = "Nazwa Przedmiotu";
		String text8 = "Oceny";
		String text9 = "Srednia ocen w semestrze";

		Connection con = MainApp.getConnection();

		ArrayList<Integer> idPrzedmiotow = new ArrayList<Integer>();
		ArrayList<String> nazwyPrzedmiotow = new ArrayList<String>();
		ArrayList<Float> oceny = new ArrayList<Float>();
		ResultSet rs = con.createStatement()
				.executeQuery("select _subject.id_przedmiotu from _subject, pupil, grades "
						+ "where _subject.id_przedmiotu = grades.id_przedmiotu " + "and "
						+ "grades.id_ucznia = pupil.id_ucznia " + "and " + "pupil.id_ucznia = " + idUcznia
						+ "group by _subject.id_przedmiotu");
		while (rs.next()) {
			idPrzedmiotow.add(rs.getInt("id_przedmiotu"));
		}
		rs = con.createStatement()
				.executeQuery("select _subject.nazwa from _subject, pupil, grades "
						+ "where _subject.id_przedmiotu = grades.id_przedmiotu " + "and "
						+ "grades.id_ucznia = pupil.id_ucznia " + "and " + "pupil.id_ucznia = " + idUcznia
						+ "group by _subject.nazwa");
		while (rs.next()) {
			nazwyPrzedmiotow.add(rs.getString("nazwa"));
		}

		ArrayList<Integer> wagaOcen = new ArrayList<Integer>();
		ArrayList<Float> listaSrednich = new ArrayList<Float>();
		int sumaWagOcen = 0;
		float wagaRazyOcena = 0;
		float sredniaPrzedmiotu;

		for (int idPrzedmiotu : idPrzedmiotow) {
			rs = con.createStatement().executeQuery("select ocena, waga from grades where id_przedmiotu = "
					+ idPrzedmiotu + " and id_ucznia = " + idUcznia);
			while (rs.next()) {
				oceny.add(rs.getFloat("ocena"));
				wagaOcen.add(rs.getInt("waga"));
			}

			for (i = 0; i < oceny.size(); i++) {
				wagaRazyOcena += oceny.get(i) * wagaOcen.get(i);
				sumaWagOcen += wagaOcen.get(i);
			}
			sredniaPrzedmiotu = wagaRazyOcena / sumaWagOcen;
			sredniaPrzedmiotu = Float.valueOf(df.format(sredniaPrzedmiotu));
			listaSrednich.add(sredniaPrzedmiotu);
		}

		ArrayList<String> textID = new ArrayList<String>();
		ArrayList<String> textNazwa = new ArrayList<String>();
		ArrayList<String> textOceny = new ArrayList<String>();
		for (i = 0; i < idPrzedmiotow.size(); i++) {
			textID.add(idPrzedmiotow.get(i).toString());
			textNazwa.add(nazwyPrzedmiotow.get(i));
			textOceny.add(listaSrednich.get(i).toString());
		}
		contentStream.setFont(PDType1Font.TIMES_BOLD, 26);
		contentStream.newLineAtOffset(200, 10);
		contentStream.showText(text1);
		contentStream.newLine();
		contentStream.newLine();
		contentStream.setFont(PDType1Font.TIMES_ROMAN, 18);
		contentStream.newLineAtOffset(-200, 0);
		contentStream.showText(text2);
		contentStream.newLine();
		contentStream.showText(text3);
		contentStream.newLine();
		contentStream.showText(text4);
		contentStream.newLine();
		contentStream.showText(text5);
		contentStream.newLine();
		contentStream.newLine();
		contentStream.newLine();
		contentStream.setFont(PDType1Font.TIMES_BOLD, 20);
		contentStream.showText(text6);
		contentStream.newLineAtOffset(80, 0);
		contentStream.showText(text7);
		contentStream.newLineAtOffset(280, 0);
		contentStream.showText(text8);
		contentStream.newLine();
		contentStream.setFont(PDType1Font.TIMES_ROMAN, 18);
		contentStream.newLineAtOffset(-360, 0);
		for (i = 0; i < textID.size(); i++) {
			contentStream.showText(textID.get(i));
			contentStream.newLineAtOffset(80, 0);
			contentStream.showText(textNazwa.get(i));
			contentStream.newLineAtOffset(280, 0);
			contentStream.showText(textOceny.get(i));
			contentStream.newLine();
			contentStream.newLineAtOffset(-360, 0);
		}
		contentStream.showText("_______________________________________________");
		contentStream.newLine();
		float srednia = 0;

		for (i = 0; i < textOceny.size(); i++) {
			srednia += Float.valueOf(textOceny.get(i));
		}
		srednia = Float.valueOf(df.format(srednia / (textOceny.size() + 1)));

		String text10 = String.valueOf(srednia);
		contentStream.setFont(PDType1Font.TIMES_BOLD, 18);
		contentStream.showText(text9);
		contentStream.newLineAtOffset(360, 0);
		contentStream.showText(text10);
		contentStream.newLine();
		contentStream.newLineAtOffset(-360, 0);

		contentStream.endText();

		contentStream.close();
		doc.save(fileName);
		doc.close();
		MainApp.showInformation("Generacja raportu z obecnosciami", "Raport został wygenerowany.",
				Alert.AlertType.INFORMATION);
	}

	public void generatePresenceReport(TablePosition pos, User user, int subjectID)
			throws IOException, ClassNotFoundException, SQLException {
		int i = 0;

		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd");
		LocalDate localDate = LocalDate.now();
		String imie = user.getName().get().replaceAll(" ", "");
		String nazwisko = user.getLastName().get().replaceAll(" ", "");
		Integer idUcznia = user.getIdUcznia();

		String fileName = imie + nazwisko + "_" + "PresenceReport" + ".pdf";
		fileName.replace(" ", "");
		PDDocument doc = new PDDocument();
		PDPage page = new PDPage();
		doc.addPage(page);

		PDPageContentStream contentStream = new PDPageContentStream(doc, page);

		String text1 = "Raport Obecnosci";
		String text2 = "Imie: " + imie;
		String text3 = "Nazwisko: " + nazwisko;
		String text4 = "ID Ucznia: " + idUcznia.toString();
		String text5 = "Data : " + dtf.format(localDate);

		Connection con = MainApp.getConnection();
		ResultSet rs;

		String nazwaPrzedmiotu = "";
		int idPrzedmiotu = 0;
		rs = con.createStatement()
				.executeQuery("select _subject.nazwa, _subject.id_przedmiotu from _subject, pupil, grades "
						+ "where _subject.id_przedmiotu = " + subjectID + "and " + "grades.id_ucznia = pupil.id_ucznia "
						+ "and " + "pupil.id_ucznia = " + idUcznia + "group by _subject.nazwa, _subject.id_przedmiotu");
		while (rs.next()) {
			nazwaPrzedmiotu = rs.getString("nazwa");
			idPrzedmiotu = rs.getInt("id_przedmiotu");
		}

		ArrayList<Integer> presenceInt = new ArrayList<Integer>();
		ArrayList<String> date = new ArrayList<String>();
		ResultSet rs1 = con.createStatement().executeQuery("select data, obecnosc from presence where id_ucznia = "
				+ idUcznia + "and id_przedmiotu = " + idPrzedmiotu + "order by data");
		while (rs1.next()) {
			presenceInt.add(rs1.getInt("obecnosc"));
			date.add(rs1.getString("data"));
		}
		contentStream.beginText();
		contentStream.setLeading(23);
		contentStream.newLineAtOffset(25, 725);
		contentStream.setFont(PDType1Font.TIMES_BOLD, 26);
		contentStream.newLineAtOffset(200, 10);
		contentStream.showText(text1);
		contentStream.newLine();
		contentStream.newLine();
		contentStream.setFont(PDType1Font.TIMES_ROMAN, 18);
		contentStream.newLineAtOffset(-200, 0);
		contentStream.showText(text2);
		contentStream.newLine();
		contentStream.showText(text3);
		contentStream.newLine();
		contentStream.showText(text4);
		contentStream.newLine();
		contentStream.showText(text5);
		contentStream.newLine();
		contentStream.newLine();
		contentStream.newLine();
		contentStream.newLineAtOffset(0, 0);

		contentStream.setFont(PDType1Font.TIMES_BOLD, 20);
		contentStream.showText(nazwaPrzedmiotu);
		contentStream.newLine();
		contentStream.newLine();
		contentStream.setFont(PDType1Font.TIMES_ROMAN, 12);
		String obecnosc = "";
		for (i = 0; i < date.size(); i++) {
			contentStream.showText(date.get(i));
			contentStream.newLineAtOffset(150, 0);
			if (presenceInt.get(i) == 1) {
				obecnosc = "Obecny";
			} else if (presenceInt.get(i) == 2) {
				obecnosc = "Nieobecny";
			} else if (presenceInt.get(i) == 3) {
				obecnosc = "Usprawiedliwiony";
			} else {
				obecnosc = "Brak danych";
			}

			contentStream.showText(obecnosc);
			contentStream.newLineAtOffset(-150, 0);

			contentStream.newLine();
		}

		contentStream.newLine();
		contentStream.endText();
		contentStream.close();
		doc.save(fileName);
		doc.close();
		MainApp.showInformation("Generacja raportu z obecnosciami", "Raport został wygenerowany.",
				Alert.AlertType.INFORMATION);

	}
}
