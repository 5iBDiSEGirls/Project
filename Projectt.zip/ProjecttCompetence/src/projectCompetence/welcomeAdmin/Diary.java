package projectCompetence.welcomeAdmin;

import java.io.Serializable;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import projectCompetence.MainApp;
import projectCompetence.welcomeAdmin.Student.PersonRow;

@SuppressWarnings("serial")
public class Diary implements Serializable {
	
	private int nextPersonNumber;
	private List<Student> listOfPerson;
	
	public Diary(String diaryName) throws ClassNotFoundException, SQLException {
			this.nextPersonNumber = 1;
			this.listOfPerson = new ArrayList<>();
			
			loadInformation();
	}
	
	private void loadInformation() throws ClassNotFoundException, SQLException {
		Statement s1 = MainApp.getStatement();
		ResultSet rs = s1.executeQuery("SELECT * from pupil");
  	  	
  	  	while (rs.next()){
  	    	listOfPerson.add(new Student(rs.getInt("id_ucznia"),
  	    			rs.getString("imie"),
  	    			rs.getString("nazwisko"),
  	    			rs.getString("adres"),
  	    			rs.getString("telefon"),
  	    			rs.getInt("id_klasy"),
  	    			rs.getString("_login"),
  	    			rs.getString("_password")));
  	    	++this.nextPersonNumber;
  	 	}
	}

	public ObservableList<PersonRow> getAllPeople() {
        ObservableList<PersonRow> people = FXCollections.observableArrayList();
        for (Student person : this.listOfPerson) {
        	people.add(person.getPersonRow());
        }
        
        return people;
    }
        
    public ObservableList<PersonRow> getFilteredPeople(String personNumber, String firstName, String lastName, String address, String tel, String classNumber, String login) {
        ObservableList<PersonRow> filteredPerson = FXCollections.observableArrayList();
        for (Student person : this.listOfPerson) {
            if (person.equals(personNumber, firstName, lastName, address, tel, classNumber, login)) {
                filteredPerson.add(person.getPersonRow());
            }
        }
        
        return filteredPerson;
    }
        
    public PersonRow createAccountStudent(String firstName, String lastName, String address, String tel, int classNumber, String login, String password) throws ClassNotFoundException, SQLException {
    	Student person = new Student(this.nextPersonNumber++, firstName, lastName, address, tel, classNumber, login, password);
    	listOfPerson.add(person);
    	Statement s1 = MainApp.getStatement();
    	
    	String sqlInsert = "insert into pupil values(" + person.getSQLData() + ")"; 
    	s1.executeUpdate(sqlInsert);
        return person.getPersonRow();
    }
        
    public boolean deleteAccount(String accountNumber) throws ClassNotFoundException, SQLException {
        int numberBefore = this.listOfPerson.size();
        this.listOfPerson.remove(Integer.valueOf(accountNumber) - 1);
        if (numberBefore != this.listOfPerson.size()) {
        	Statement s1 = MainApp.getStatement();
        	
        	String sqlDelete = "delete pupil where id_ucznia = " + accountNumber; 
        	s1.executeUpdate(sqlDelete);
            return true;
        } else {
            return false;
        }
    }
}
