
package projectCompetence.timeTable;

import java.io.File;
import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import projectCompetence.MainApp;
import projectCompetence.timeTable.openScheduleTeacher;




public class TimeTableOpenController {

	private MainApp mainApp;
	private static AnchorPane rootLayout;
	static File file;
	
	@FXML
	private void LogoutButtonAction(ActionEvent event) throws Exception{
		if(MainApp.showQuestionDialog("Potwierdzenie", "Czy napewno chcesz sie wylogowa�?", "")) {
			mainApp.loadStage();
		}
	}

	@FXML
	private void open16(ActionEvent event) throws Exception{
		file = openScheduleTeacher.createFile(0);
		openSchedule.runWindow();
	}
	
	public static File getFile() {
		return file;
	}

	@FXML
	private void open1(ActionEvent event) throws Exception{
		file = openScheduleTeacher.createFile(1);
		openSchedule.runWindow();
	}
	
	@FXML
	private void open2(ActionEvent event) throws Exception{
		file = openScheduleTeacher.createFile(2);
		openSchedule.runWindow();
	}
	
	@FXML
	private void open3(ActionEvent event) throws Exception{
		file = openScheduleTeacher.createFile(3);
		openSchedule.runWindow();
	}
	
	@FXML
	private void open4(ActionEvent event) throws Exception{
		file = openScheduleTeacher.createFile(4);
		openSchedule.runWindow();
	}
	
	
	@FXML
	private void open5(ActionEvent event) throws Exception{
		file = openScheduleTeacher.createFile(5);
		openSchedule.runWindow();
	}
	
	@FXML
	private void open6(ActionEvent event) throws Exception{
		file = openScheduleTeacher.createFile(6);
		openSchedule.runWindow();
	}
	
	

	@FXML
	private void open7(ActionEvent event) throws Exception{
		file = openScheduleTeacher.createFile(7);
		openSchedule.runWindow();
	}
	
	@FXML
	private void open8(ActionEvent event) throws Exception{
		file = openScheduleTeacher.createFile(8);
		openSchedule.runWindow();
	}
	
	@FXML
	private void open9(ActionEvent event) throws Exception{
		file = openScheduleTeacher.createFile(9);
		openSchedule.runWindow();
	}
	
	@FXML
	private void open10(ActionEvent event) throws Exception{
		file = openScheduleTeacher.createFile(10);
		openSchedule.runWindow();
	}
	@FXML
	private void open11(ActionEvent event) throws Exception{
		file = openScheduleTeacher.createFile(11);
		openSchedule.runWindow();
	}
	
	

	@FXML
	private void open12(ActionEvent event) throws Exception{
		file = openScheduleTeacher.createFile(12);
		openSchedule.runWindow();
	}
	
	@FXML
	private void open13(ActionEvent event) throws Exception{
		file = openScheduleTeacher.createFile(13);
		openSchedule.runWindow();
	}
	
	@FXML
	private void open14(ActionEvent event) throws Exception{
		file = openScheduleTeacher.createFile(14);
		openSchedule.runWindow();
	}
	
	@FXML
	private void open15(ActionEvent event) throws Exception{
		file = openScheduleTeacher.createFile(15);
		openSchedule.runWindow();
	}
	

	public static void start(MainApp mainApp) {
		try {
		  	
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(MainApp.class.getResource("timeTable/TeacherO.fxml"));
			rootLayout = loader.load();
			
			Scene scene = new Scene(rootLayout);
			mainApp.getStage().setScene(scene);
			mainApp.getStage().setTitle("Plan nauczyciela");

		} catch (IOException e) {
		    e.printStackTrace();
		}
}
	
}
