
package projectCompetence.timeTable;

import java.awt.Cursor;
import java.io.File;

import javax.swing.JOptionPane;
import javax.swing.JTable;

import jxl.Sheet;
import jxl.Workbook;
import projectCompetence.welcomeTeacher.TeacherController;


public class openScheduleTeacher extends javax.swing.JFrame {

	private javax.swing.JMenu jMenu1;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JTable jTable1;
	
    public static String[] namesOfFile = {"1.xls","2.xls","3.xls","4.xls","5.xls","6.xls","7.xls","8.xls","9.xls","10.xls","11.xls","12.xls","13.xls","14.xls","15.xls","16.xls"};
    
    public openScheduleTeacher() {
        initComponents();
    }
    
    private void initComponents() {
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenuItem1 = new javax.swing.JMenuItem();
        jSeparator1 = new javax.swing.JSeparator();
        jMenuItem2 = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "", "", "", ""
            }
        ));
        
        jScrollPane1.setViewportView(jTable1);

        jMenu1.setText("Plan zaj��");
        jMenuItem1.setText("Open");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });

        jMenu1.add(jMenuItem1);

        jMenu1.add(jSeparator1);

        jMenuItem2.setText("Wyj�cie");
        
        jMenuItem2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem2ActionPerformed(evt);
            }
        });

        jMenu1.add(jMenuItem2);

        jMenuBar1.add(jMenu1);

        setJMenuBar(jMenuBar1);
//
        org.jdesktop.layout.GroupLayout layout = new org.jdesktop.layout.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(layout.createSequentialGroup()
                .addContainerGap()
                .add(jScrollPane1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 800, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(layout.createSequentialGroup()
                .addContainerGap()
                .add(jScrollPane1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 240, Short.MAX_VALUE)
                .addContainerGap())
        );
        pack();
    }
    
    public static void runWindow() {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new openScheduleTeacher().setVisible(true);
            }
        });
        
    }
    
    public static File createFile(int i) {
    	File file = new File(namesOfFile[i]);
    	return file;
    }
    
    private void jMenuItem2ActionPerformed(java.awt.event.ActionEvent evt) {
        dispose();
       // System.exit(1);
    }
    
    
	
	
    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {
        
    	File file = TeacherController.getFile();
        setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
        
        Sheet sheet = readExcelSheet(file);
        if (sheet != null) {
            displaySheet(sheet, jTable1);
        }
        
        setCursor(Cursor.getDefaultCursor());
    }
    
    private Sheet readExcelSheet(File file) {
        
        Workbook wbk;
        try {
            wbk = Workbook.getWorkbook(file);
        } catch (Exception ex) {
            JOptionPane message = new JOptionPane(
                    "Can't read excel file " + file.getPath(),
                    JOptionPane.ERROR_MESSAGE);
            return null;
        }
        if (wbk.getNumberOfSheets() <= 0) {
            JOptionPane message = new JOptionPane(
                    "Excel file doesn't have any sheets.",
                    JOptionPane.ERROR_MESSAGE);
            return null;
        }
       
        return wbk.getSheet(0);
    }
    
    private void displaySheet(Sheet sheet, JTable table) {
        table.setModel(new SheetTableModel(sheet));
    }
    
}