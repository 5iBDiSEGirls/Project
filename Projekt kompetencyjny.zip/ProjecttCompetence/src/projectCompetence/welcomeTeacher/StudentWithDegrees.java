package projectCompetence.welcomeTeacher;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import javafx.beans.property.SimpleStringProperty;
import projectCompetence.Grade;

public class StudentWithDegrees {
	
	private String firstName;
	private String lastName;
	private List<Grade> grades = new ArrayList<>();
	
	
	public StudentWithDegrees(String firstName, String lastName) {
		this.firstName = firstName;
		this.lastName = lastName;
	}
	
	public void addGrade(Grade grade) {
		this.grades.add(grade);
	}
	
	public StudentWithDegreesRow getStudentWithDegreesRow() {
		String g1 = grades.stream().filter(g -> g.getWeight() == 1).map(Grade::toString).collect(Collectors.joining(", ")),
				g2 = grades.stream().filter(g -> g.getWeight() == 2).map(Grade::toString).collect(Collectors.joining(", ")),
				g3 = grades.stream().filter(g -> g.getWeight() == 3).map(Grade::toString).collect(Collectors.joining(", ")),
				g4 = grades.stream().filter(g -> g.getWeight() == 4).map(Grade::toString).collect(Collectors.joining(", ")),
				g5 = grades.stream().filter(g -> g.getWeight() == 5).map(Grade::toString).collect(Collectors.joining(", "));
		
		return new StudentWithDegreesRow(firstName, lastName, g1, g2, g3, g4, g5);
	}
	
	public class StudentWithDegreesRow {
	    
        private final SimpleStringProperty firstNameField;
        private final SimpleStringProperty lastNameField;
        private final SimpleStringProperty gradesWith1weight;
        private final SimpleStringProperty gradesWith2weight;
		private final SimpleStringProperty gradesWith3weight;
		private final SimpleStringProperty gradesWith4weight;
		private final SimpleStringProperty gradesWith5weight;
		private final SimpleStringProperty newGradeField;
		private final SimpleStringProperty newWeightField;

        private StudentWithDegreesRow(String firstNameField, String lastNameField, String gradesWith1weight, String gradesWith2weight, String gradesWith3weight, String gradesWith4weight, String gradesWith5weight) {
            this.firstNameField = new SimpleStringProperty(firstNameField);
            this.lastNameField = new SimpleStringProperty(lastNameField);
            this.gradesWith1weight = new SimpleStringProperty(gradesWith1weight);
            this.gradesWith2weight = new SimpleStringProperty(gradesWith2weight);
            this.gradesWith3weight = new SimpleStringProperty(gradesWith3weight);
            this.gradesWith4weight = new SimpleStringProperty(gradesWith4weight);
            this.gradesWith5weight = new SimpleStringProperty(gradesWith5weight);
            this.newGradeField = new SimpleStringProperty();
            this.newWeightField = new SimpleStringProperty();
        }

		public SimpleStringProperty getId_degree() {
			return firstNameField;
		}

		public SimpleStringProperty getDegree() {
			return lastNameField;
		}

		public SimpleStringProperty getGradesWith1weight() {
			return gradesWith1weight;
		}

		public SimpleStringProperty getGradesWith2weight() {
			return gradesWith2weight;
		}

		public SimpleStringProperty getGradesWith3weight() {
			return gradesWith3weight;
		}

		public SimpleStringProperty getGradesWith4weight() {
			return gradesWith4weight;
		}

		public SimpleStringProperty getGradesWith5weight() {
			return gradesWith5weight;
		}

		public SimpleStringProperty getNewGradeField() {
			return newGradeField;
		}

		public SimpleStringProperty getNewWeightField() {
			return newWeightField;
		}
        
    }
}
