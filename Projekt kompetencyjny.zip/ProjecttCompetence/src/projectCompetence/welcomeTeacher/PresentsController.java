package projectCompetence.welcomeTeacher;

import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import projectCompetence.MainApp;

public class PresentsController implements Initializable{
	@FXML
	private TableView<User> tableUser;
	@FXML
	private TableColumn<User,String> columnName;
	@FXML
	private TableColumn<User,String> columnLastName;
	@FXML
	private TableColumn<User,String> columnPresenceView;
	@FXML
	private TableColumn<User,String> columnAbsenceView;
	@FXML
	private TableColumn<User,String> columnExcusedView;
	private ObservableList<User>data;
	int numberId;
	public void setId(int numberId) {
		this.numberId = numberId;
		
	}
	@Override
	public void initialize(URL url, ResourceBundle rb) {
		
	}
	public void LoadDataFromDatabasePresents() throws ClassNotFoundException {
		try{
			Connection con = MainApp.getConnection();
			data = FXCollections.observableArrayList();
			System.out.println(numberId);
			ResultSet rs=con.createStatement().executeQuery("select p.imie, p.nazwisko, sum(case when obecnosc = 1 then 1 else 0 end) as obecnosci,sum(case when obecnosc = 2 then 1 else 0 end) nieobecnosc,sum(case when  o.obecnosc = 3 then 1 else 0 end) usprawiedliwiony from pupil p join presence o on p.id_ucznia = o.id_ucznia where p.id_klasy="+numberId+" group by p.imie, p.nazwisko;");
			while(rs.next()){
				data.add(new User(rs.getString("imie"),rs.getString("nazwisko"),rs.getInt("obecnosci"),rs.getInt("nieobecnosc"),rs.getInt("usprawiedliwiony")));
			}
			
		}catch (SQLException ex){
			System.err.println("Error" + ex);
		}
			columnName.setCellValueFactory(new PropertyValueFactory<>("name"));
			columnLastName.setCellValueFactory(new PropertyValueFactory<>("lastName"));
			columnPresenceView.setCellValueFactory(new PropertyValueFactory<>("presString"));
			columnAbsenceView.setCellValueFactory(new PropertyValueFactory<>("absString"));
			columnExcusedView.setCellValueFactory(new PropertyValueFactory<>("excString"));
			
			
			
			tableUser.setItems(data);
			

	}
}
