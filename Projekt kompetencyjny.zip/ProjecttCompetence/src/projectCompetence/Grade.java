package projectCompetence;

import java.io.Serializable;
import java.util.Arrays;
import java.util.List;

import javafx.beans.property.SimpleStringProperty;

@SuppressWarnings("serial")
public class Grade implements Serializable {
	
	private final static List<String> listOfCorrectDegrees = Arrays.asList("1", "1.5", "2", "2.5", "3", "3.5", "4", "4.5", "5", "5.5", "6");
	
	private Integer id_degree;
    private String degree;
    private int id_subject;
    private int weight;
    private int id_student;
    
    
	public Grade(String degree, int id_subject, int weight, int id_student) {
		this.id_degree = null;
		this.degree = degree;
		this.id_subject = id_subject;
		this.weight = weight;
		this.id_student = id_student;
	}
	
	public Grade(Integer id_degree, String degree, int id_subject, int weight, int id_student) {
		this(degree, id_subject, weight, id_student);
		this.id_degree = id_degree;
	}
	
	public Integer getId_degree() {
		return id_degree;
	}

	public String getDegree() {
		return degree;
	}

	public int getId_subject() {
		return id_subject;
	}

	public int getWeight() {
		return weight;
	}

	public int getId_student() {
		return id_student;
	}
	
	public DegreeRow getDegreeRow() {
		return new DegreeRow(id_degree.toString(), 
				degree,
				String.valueOf(id_subject),
				String.valueOf(weight),
				String.valueOf(id_student));
	}
	
	public String getSQLData() {
		return "'" + this.degree + "', " +
				this.id_subject + ", " +
				this.weight + ", " +
				this.id_student;
	}
	
	public static boolean isValid(String value) {
		return listOfCorrectDegrees.stream().filter(degree -> degree.equals(value)).count() > 0;
	}
	
	@Override
	public String toString() {
		return degree + "(" + weight + ")";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((degree == null) ? 0 : degree.hashCode());
		result = prime * result + ((id_degree == null) ? 0 : id_degree.hashCode());
		result = prime * result + id_student;
		result = prime * result + id_subject;
		result = prime * result + weight;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Grade other = (Grade) obj;
		if (degree == null) {
			if (other.degree != null)
				return false;
		} else if (!degree.equals(other.degree))
			return false;
		if (id_degree == null) {
			if (other.id_degree != null)
				return false;
		} else if (!id_degree.equals(other.id_degree))
			return false;
		if (id_student != other.id_student)
			return false;
		if (id_subject != other.id_subject)
			return false;
		if (weight != other.weight)
			return false;
		return true;
	}	
	
	public class DegreeRow {
	    
        private final SimpleStringProperty id_degree;
        private final SimpleStringProperty degree;
        private final SimpleStringProperty id_subject;
        private final SimpleStringProperty weight;
		private final SimpleStringProperty id_student;

        private DegreeRow(String id_degree, String degree, String id_subject, String weight, String id_student) {
            this.id_degree = new SimpleStringProperty(id_degree);
            this.degree = new SimpleStringProperty(degree);
            this.id_subject = new SimpleStringProperty(id_subject);
            this.weight = new SimpleStringProperty(weight);
            this.id_student = new SimpleStringProperty(id_student);
        }

		public SimpleStringProperty getId_degree() {
			return id_degree;
		}

		public SimpleStringProperty getDegree() {
			return degree;
		}

		public SimpleStringProperty getId_subject() {
			return id_subject;
		}

		public SimpleStringProperty getWeight() {
			return weight;
		}

		public SimpleStringProperty getId_student() {
			return id_student;
		}
        
        
    }
}
