package projectCompetence.welcomeTeacher;

import javafx.beans.property.StringProperty;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;

public class User {
	
	private StringProperty name;
	private StringProperty lastName;
	private StringProperty email;
	private IntegerProperty present;
	private Integer idUcznia;
	private BooleanProperty presents = new SimpleBooleanProperty(false);
	private BooleanProperty absent = new SimpleBooleanProperty(false);
	private BooleanProperty excused = new SimpleBooleanProperty(false);

	
	public Integer getIdUcznia() {
		return idUcznia;
	}
	public void setIdUcznia(Integer idUcznia) {
		this.idUcznia = idUcznia;
	}
	public void setPresent(Integer present) {
		this.present = new SimpleIntegerProperty(present);
	}
	public Integer getPresent() {
		return present.get();
	}
	public void setEditedPresent() {
		if(presents.equals(true))
			setPresent(1);
		if(absent.equals(true))
			setPresent(2);
		if(excused.equals(true))
			setPresent(3);
	}
	public BooleanProperty getPresents() {
	
		return presents;
	}
	public void setPresents(Boolean presents) {
		System.out.println("Test");
		this.presents = new SimpleBooleanProperty(presents);
		setEditedPresent();
	}
	public BooleanProperty getAbsent() {
		return absent;
	}
	public void setAbsent(Boolean absent) {
		this.absent = new SimpleBooleanProperty(absent);
		setEditedPresent();
	}
	public BooleanProperty getExcused() {
		return excused;
	}
	public void setExcused(Boolean excused) {
		this.excused = new SimpleBooleanProperty(excused);
		setEditedPresent();
	}
	public String getEmail() {
		return email.get();
	}
	public void setEmail(String email) {
		this.email = new SimpleStringProperty(email);
	}
	public User(String name, String lastName, String email) {
		this.name = new SimpleStringProperty(name);
		this.lastName = new SimpleStringProperty(lastName);
		this.email = new SimpleStringProperty(email);
	}
	public User(String name, String lastName, Integer present, Integer idUcznia) {
		this.name = new SimpleStringProperty(name);
		this.lastName = new SimpleStringProperty(lastName);
		this.present = new SimpleIntegerProperty(present);
		this.idUcznia = idUcznia;
		setValue(present);
	}
	public void setValue(Integer present) {
		switch(present) {
		case 1: this.presents = new SimpleBooleanProperty(true);
		break;
		case 2: this.absent = new SimpleBooleanProperty(true);
		break;
		case 3: this.excused = new SimpleBooleanProperty(true);
		break;
		}
	}
	public String getName() {return name.get();}
	public String getLastName() {return lastName.get();}
	
	public void setName(String value) {
		name.set(value);
	}
	public void setLastName(String value) {
		lastName.set(value);
	}
	@Override
	public String toString() {
		return "User [name=" + name + ", lastName=" + lastName + ", email=" + email + ", present=" + present
				+ ", idUcznia=" + idUcznia + ", presents=" + presents + ", absent=" + absent + ", excused=" + excused
				+ "]";
	}


}