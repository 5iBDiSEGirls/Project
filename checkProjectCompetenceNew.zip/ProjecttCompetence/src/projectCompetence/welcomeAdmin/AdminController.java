package projectCompetence.welcomeAdmin;

import java.io.IOException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import projectCompetence.MainApp;

public class AdminController {

	private MainApp mainApp;
	
	private static AnchorPane rootLayout;

	@FXML
	private void LogoutButtonAction(ActionEvent event) throws Exception{
		if(MainApp.showQuestionDialog("Potwierdzenie", "Czy napewno chcesz sie wylogowa�?", "")) {
			mainApp.loadStage();
		}
	}
	
	@FXML
	private void studentsButtonAction() throws Exception{
		StudentEditController sec = new StudentEditController();
		sec.show();
	}
	
	@FXML
	private void teacherButtonAction() throws Exception{
		TeacherEditController tec = new TeacherEditController();
		tec.show();
	}


	@FXML
	private void planButtonAction() throws Exception{
		TimeTableEdit pl = new TimeTableEdit();
		pl.show();
	}

	public static void showAdmin(MainApp mainApp) {
		try {
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(MainApp.class.getResource("welcomeAdmin/Admin.fxml"));
			rootLayout = loader.load();
			((AdminController) loader.getController()).setMainApp(mainApp);
			Scene scene = new Scene(rootLayout);
			mainApp.getStage().setScene(scene);
			mainApp.getStage().setResizable(false);
			mainApp.getStage().setTitle("Administrator");
		} catch (IOException e) {
		    e.printStackTrace();
		}
}

	private void setMainApp(MainApp mainApp) {
		this.mainApp = mainApp;
		
	}
}
