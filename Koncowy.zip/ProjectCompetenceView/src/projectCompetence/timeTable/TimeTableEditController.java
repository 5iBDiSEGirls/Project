
package projectCompetence.timeTable;

import java.awt.Desktop;
import java.io.File;
import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import projectCompetence.MainApp;



public class TimeTableEditController {

	
	private static AnchorPane rootLayout;
	static File file;
	

	@FXML
	private void go0(ActionEvent event) throws Exception{
		Desktop dk =null;
    	
        dk =Desktop.getDesktop();
        try {
			dk.open(new File ( "1.xls"));
		} catch (IOException e) {
			
			e.printStackTrace();
		}
	}
	
	

	@FXML
	private void go1(ActionEvent event) throws Exception{
		Desktop dk =null;
    	
        dk =Desktop.getDesktop();
        try {
			dk.open(new File ( "2.xls"));
		} catch (IOException e) {
			
			e.printStackTrace();
		}
	}
	
	@FXML
	private void go2(ActionEvent event) throws Exception{
		Desktop dk =null;
    	
        dk =Desktop.getDesktop();
        try {
			dk.open(new File ( "3.xls"));
		} catch (IOException e) {
			
			e.printStackTrace();
		}
	}
	
	@FXML
	private void go3(ActionEvent event) throws Exception{
		Desktop dk =null;
    	
        dk =Desktop.getDesktop();
        try {
			dk.open(new File ( "4.xls"));
		} catch (IOException e) {
			
			e.printStackTrace();
		}
	}
	
	@FXML
	private void go4(ActionEvent event) throws Exception{
		
		Desktop dk =null;
    	
        dk =Desktop.getDesktop();
        try {
			dk.open(new File ( "16.xls"));
		} catch (IOException e) {
			
			e.printStackTrace();
		}
	}
	
	
	@FXML
	private void go5(ActionEvent event) throws Exception{
		Desktop dk =null;
    	
        dk =Desktop.getDesktop();
        try {
			dk.open(new File ( "5.xls"));
		} catch (IOException e) {
			
			e.printStackTrace();
		}
	}
	
	@FXML
	private void go6(ActionEvent event) throws Exception{
		Desktop dk =null;
    	
        dk =Desktop.getDesktop();
        try {
			dk.open(new File ( "6.xls"));
		} catch (IOException e) {
			
			e.printStackTrace();
		}
	}
	
	

	@FXML
	private void go7(ActionEvent event) throws Exception{
		Desktop dk =null;
    	
        dk =Desktop.getDesktop();
        try {
			dk.open(new File ( "7.xls"));
		} catch (IOException e) {
			
			e.printStackTrace();
		}
	}
	
	@FXML
	private void go8(ActionEvent event) throws Exception{
		Desktop dk =null;
    	
        dk =Desktop.getDesktop();
        try {
			dk.open(new File ( "8.xls"));
		} catch (IOException e) {
			
			e.printStackTrace();
		}
	}
	
	@FXML
	private void go9(ActionEvent event) throws Exception{
		Desktop dk =null;
    	
        dk =Desktop.getDesktop();
        try {
			dk.open(new File ( "9.xls"));
		} catch (IOException e) {
	
			e.printStackTrace();
		}
	}
	
	@FXML
	private void go10(ActionEvent event) throws Exception{
		Desktop dk =null;
    	
        dk =Desktop.getDesktop();
        try {
			dk.open(new File ( "10.xls"));
		} catch (IOException e) {
			
			e.printStackTrace();
		}
	}
	@FXML
	private void go11(ActionEvent event) throws Exception{
		Desktop dk =null;
    	
        dk =Desktop.getDesktop();
        try {
			dk.open(new File ( "11.xls"));
		} catch (IOException e) {
			
			e.printStackTrace();
		}
	}
	@FXML
	private void go12(ActionEvent event) throws Exception{
		Desktop dk =null;
    	
        dk =Desktop.getDesktop();
        try {
			dk.open(new File ( "12.xls"));
		} catch (IOException e) {
			
			e.printStackTrace();
		}
	}
	@FXML
	private void go13(ActionEvent event) throws Exception{
		Desktop dk =null;
    	
        dk =Desktop.getDesktop();
        try {
			dk.open(new File ( "13.xls"));
		} catch (IOException e) {
			
			e.printStackTrace();
		}
	}
	@FXML
	private void go14(ActionEvent event) throws Exception{
		Desktop dk =null;
    	
        dk =Desktop.getDesktop();
        try {
			dk.open(new File ( "14.xls"));
		} catch (IOException e) {
			
			e.printStackTrace();
		}
	}
	@FXML
	private void go15(ActionEvent event) throws Exception{
		Desktop dk =null;
    	
        dk =Desktop.getDesktop();
        try {
			dk.open(new File ( "15.xls"));
		} catch (IOException e) {
			
			e.printStackTrace();
		}
	}
	
	@FXML
	private void kl1(ActionEvent event) throws Exception{
		Desktop dk =null;
    	
        dk =Desktop.getDesktop();
        try {
			dk.open(new File ( "1A.xls"));
		} catch (IOException e) {
			
			e.printStackTrace();
		}
	}
	@FXML
	private void kl2(ActionEvent event) throws Exception{
		Desktop dk =null;
    	
        dk =Desktop.getDesktop();
        try {
			dk.open(new File ( "1B.xls"));
		} catch (IOException e) {
			
			e.printStackTrace();
		}
	}
	@FXML
	private void kl3(ActionEvent event) throws Exception{
		Desktop dk =null;
    	
        dk =Desktop.getDesktop();
        try {
			dk.open(new File ( "2A.xls"));
		} catch (IOException e) {
			
			e.printStackTrace();
		}
	}
	@FXML
	private void kl4(ActionEvent event) throws Exception{
		Desktop dk =null;
    	
        dk =Desktop.getDesktop();
        try {
			dk.open(new File ( "2B.xls"));
		} catch (IOException e) {
			
			e.printStackTrace();
		}
	}
	@FXML
	private void kl5(ActionEvent event) throws Exception{
		Desktop dk =null;
    	
        dk =Desktop.getDesktop();
        try {
			dk.open(new File ( "3A.xls"));
		} catch (IOException e) {
			
			e.printStackTrace();
		}
	}
	@FXML
	private void kl6(ActionEvent event) throws Exception{
		Desktop dk =null;
    	
        dk =Desktop.getDesktop();
        try {
			dk.open(new File ( "3B.xls"));
		} catch (IOException e) {
			
			e.printStackTrace();
		}
	}

	public static void start(MainApp mainApp) {
		try {
		  	
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(MainApp.class.getResource("timeTable/TeacherT.fxml"));
			rootLayout = loader.load();
			
			Scene scene = new Scene(rootLayout);
			mainApp.getStage().setScene(scene);
			mainApp.getStage().setTitle("Edycja - Konto Administratora");

		} catch (IOException e) {
		    e.printStackTrace();
		}
}
	
}
