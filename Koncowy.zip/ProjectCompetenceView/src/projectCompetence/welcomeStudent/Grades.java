package projectCompetence.welcomeStudent;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Grades {
public Grades(Integer subjectID, String subjectName, String grade) {
		super();
		this.subjectID = subjectID;
		this.subjectName = new SimpleStringProperty(subjectName);
		this.grade = new SimpleStringProperty(grade);
	}

	private Integer subjectID;
	private StringProperty subjectName;
	private StringProperty grade;
	
	public Integer getSubjectID() {
		return subjectID;
	}
	public void setIdUcznia(Integer subjectID) {
		this.subjectID = subjectID;
	}
	
	public String getSubjectName() {
		return subjectName.get();
	}
	public void setSubjectName(String name) {
		subjectName.set(name);
	}
	
	public String getGrade() {
		return grade.get();
	}
	public void setGrade(String grade1) {
		grade.set(grade1);
	}
	
	@Override
	public String toString() {
		return "Grades [subjectID=" + subjectID + ", subjectName=" + subjectName + ", grade=" + grade + "]";
	}
}
