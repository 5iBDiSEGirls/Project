package projectCompetence.welcomeTeacher;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.ResourceBundle;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.font.PDType1Font;

import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.MenuButton;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TablePosition;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.CheckBoxTableCell;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import javafx.util.Callback;
import projectCompetence.MainApp;


public class ClassController implements Initializable {
	int numberId;
	public void setId(int numberId) {
		this.numberId = numberId;
		
	}
	String selectedMenuItem;
	HashMap<String,Integer> subject = new HashMap<String,Integer>();
	@FXML
	private TableView<User> tableUser;
	@FXML
	private TableColumn<User,String> columnName;
	@FXML
	private TableColumn<User,String> columnLastName;
	@FXML
	private TableColumn columnPresence;
	
	@FXML
	private TableColumn<User,Boolean> columnPresent = new TableColumn<User,Boolean>("Obecny");
	@FXML
	private TableColumn<User,Boolean> columnAbsent = new TableColumn<User,Boolean>("Nieobecny");
	@FXML
	private TableColumn<User,Boolean> columnExcused = new TableColumn<User,Boolean>("Usprawiedliwiony");
	@FXML
	private TableColumn<User,String> columnEmail;
	@FXML 
	private MenuButton menuButton; 
	
	@FXML
	private Button btnSave;
	
	@FXML
	private Button btnGenerateReport;
	
	@FXML
	private DatePicker dp;
	
	private ObservableList<User>data;
	private LocalDate date;
	
	

	@Override
	public void initialize(URL url, ResourceBundle rb) {
		
	}
	@FXML
	private void datePickerAction(ActionEvent event) {
	    date = dp.getValue();

	}
	public void LoadDataFromDatabaseeAdres(String select) throws ClassNotFoundException{
		try{
		Connection con = MainApp.getConnection();
		data = FXCollections.observableArrayList();
		ResultSet rs=con.createStatement().executeQuery("select imie, nazwisko, _login from "+select+" order by nazwisko;");
		

		while(rs.next()){
			data.add(new User(rs.getString("imie"),rs.getString("nazwisko"),rs.getString("_login")));
		}
		
	}catch (SQLException ex){
		System.err.println("Error" + ex);
	}
		
		columnName.setCellValueFactory(new PropertyValueFactory<>("name"));
		columnLastName.setCellValueFactory(new PropertyValueFactory<>("lastName"));
		columnEmail.setCellValueFactory(new PropertyValueFactory<>("email"));
		
		
		
		tableUser.setItems(data);
		

}
	@FXML
	private void SaveDataToDatabasee(ActionEvent event) throws ClassNotFoundException{
		try {
			List<Boolean> present = new ArrayList<Boolean>();
			List<Boolean> absent = new ArrayList<Boolean>();
			List<Boolean> excused = new ArrayList<Boolean>();
			for(int i = 0;i < data.size();i++){
				System.out.println(columnPresent.getCellFactory().call(columnPresent).isSelected());
				present.add(columnPresent.getCellData(i));
				absent.add(columnAbsent.getCellData(i));
				excused.add(columnExcused.getCellData(i));
			}
			//for(Boolean item:absent)
			//	System.out.println(item);
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			Connection con = DriverManager
					.getConnection("jdbc:sqlserver://project-competence.database.windows.net:1433;"
							+ "database=School;user=BDiSE@project-competence;password=dreamTeam1;encrypt=true;"
							+ "trustServerCertificate=false;hostNameInCertificate=*.database.windows.net;loginTimeout=30;");

			Statement s1 = con.createStatement();
			
			
			
			for(int i = 0; i < data.size(); i++) {
			 String sqlInsert ="insert into presence values('"+date+"',"+subject.get(selectedMenuItem)+","+data.get(i).getIdUcznia()+","+data.get(i).getPresent()+")"; 
			 s1.executeUpdate(sqlInsert);
			}
			

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public void addListeners() {
		ObservableList<MenuItem> items = menuButton.getItems();
		for(MenuItem item: items) {
		item.setOnAction(event -> {
		    selectedMenuItem = item.getText();
		    menuButton.setText(item.getText());
		});
		}
	}
	public void setData() throws ClassNotFoundException {
		try{
			Connection con = MainApp.getConnection();
			columnPresence.getColumns().addAll(columnPresent,columnAbsent,columnExcused);
			data = FXCollections.observableArrayList();
			ResultSet rs=con.createStatement().executeQuery("select imie, nazwisko,id_ucznia from pupil where id_klasy="+numberId+" order by nazwisko;");
			ResultSet rs1=con.createStatement().executeQuery("select id_przedmiotu,nazwa from _subject;");
			while(rs.next()){
				data.add(new User(rs.getString("imie"),rs.getString("nazwisko"),0,rs.getInt("id_ucznia")));
			}
			while(rs1.next()){
				menuButton.getItems().add(new MenuItem(rs1.getString("nazwa")));
				subject.put(rs1.getString("nazwa"), rs1.getInt("id_przedmiotu"));
			}
			addListeners();
		}catch (SQLException ex){
			System.err.println("Error" + ex);
		}
			
			columnName.setCellValueFactory(new PropertyValueFactory<>("name"));
			columnLastName.setCellValueFactory(new PropertyValueFactory<>("lastName"));
			columnPresent.setCellValueFactory(new PropertyValueFactory<>("presents"));
			columnAbsent.setCellValueFactory(new PropertyValueFactory<>("absent"));
			columnExcused.setCellValueFactory(new PropertyValueFactory<>("excused"));
			columnPresent.setCellFactory(CheckBoxTableCell.forTableColumn(columnPresent));
			columnAbsent.setCellFactory(CheckBoxTableCell.forTableColumn(columnAbsent));
			columnExcused.setCellFactory(CheckBoxTableCell.forTableColumn(columnExcused));
			columnPresent.setCellValueFactory(c -> c.getValue().getPresents());
			columnAbsent.setCellValueFactory(c -> c.getValue().getAbsent());
			columnExcused.setCellValueFactory(c -> c.getValue().getExcused());
			columnPresent.setCellFactory(new Callback<TableColumn<User, Boolean>, TableCell<User, Boolean>>() {
	            @Override
	            public TableCell<User, Boolean> call(TableColumn<User, Boolean> p) {
	            	final CheckBoxTableCell<User, Boolean> ctCell = new CheckBoxTableCell<>();
	            	final BooleanProperty selected = new SimpleBooleanProperty();
	            	ctCell.setSelectedStateCallback(new Callback<Integer, ObservableValue<Boolean>>() {
	            	    @Override
	            	    public ObservableValue<Boolean> call(Integer index) {
	            	        return selected ;
	            	    }
	            	});
	            	selected.addListener(new ChangeListener<Boolean>() {
	            	    @Override
	            	    public void changed(ObservableValue<? extends Boolean> obs, Boolean wasSelected, Boolean isSelected) {
	            	    	System.out.println(obs);
	            	    	//w tym miejscu zmiana wartosci dla zaznaczonego ucznia, problem!!!
	            	    	//System.out.println(tableUser.getItems().get(1));
	            	    }
	            	});
	                return ctCell;
	            }
	        });

			columnAbsent.setCellFactory(new Callback<TableColumn<User, Boolean>, TableCell<User, Boolean>>() {
	            @Override
	            public TableCell<User, Boolean> call(TableColumn<User, Boolean> p) {
	            	final CheckBoxTableCell<User, Boolean> ctCell = new CheckBoxTableCell<>();
	            	final BooleanProperty selected = new SimpleBooleanProperty();
	            	ctCell.setSelectedStateCallback(new Callback<Integer, ObservableValue<Boolean>>() {
	            	    @Override
	            	    public ObservableValue<Boolean> call(Integer index) {
	            	        return selected ;
	            	    }
	            	});
	            	selected.addListener(new ChangeListener<Boolean>() {
	            	    @Override
	            	    public void changed(ObservableValue<? extends Boolean> obs, Boolean wasSelected, Boolean isSelected) {
	            	    	System.out.println(isSelected);
	            	    }
	            	});
	                return ctCell;
	            }
	        });
			columnExcused.setCellFactory(new Callback<TableColumn<User, Boolean>, TableCell<User, Boolean>>() {
	            @Override
	            public TableCell<User, Boolean> call(TableColumn<User, Boolean> p) {
	            	final CheckBoxTableCell<User, Boolean> ctCell = new CheckBoxTableCell<>();
	            	final BooleanProperty selected = new SimpleBooleanProperty();
	            	ctCell.setSelectedStateCallback(new Callback<Integer, ObservableValue<Boolean>>() {
	            	    @Override
	            	    public ObservableValue<Boolean> call(Integer index) {
	            	        return selected ;
	            	    }
	            	});
	            	selected.addListener(new ChangeListener<Boolean>() {
	            	    @Override
	            	    public void changed(ObservableValue<? extends Boolean> obs, Boolean wasSelected, Boolean isSelected) {
	            	    	
	            	    	System.out.println(isSelected);
	            	        
	            	    }
	            	});
	                return ctCell;
	            }
	        });

			/*columnPresent.setOnEditCommit(
				    new EventHandler<CellEditEvent<User, Boolean>>() {
				        @Override
				        public void handle(CellEditEvent<User, Boolean> t) {
				        	System.out.println("test");
				            ((User) t.getTableView().getItems().get(
				                t.getTablePosition().getRow())
				                ).setPresents(true);
				        }
				    }
				);
			columnAbsent.setOnEditCommit(
					new EventHandler<CellEditEvent<User, Boolean>>() {
				        @Override
				        public void handle(CellEditEvent<User, Boolean> t) {
				            ((User) t.getTableView().getItems().get(
				                t.getTablePosition().getRow())
				                ).setAbsent(true);
				        }
				    }
				);
			columnExcused.setOnEditCommit(
					new EventHandler<CellEditEvent<User, Boolean>>() {
				        @Override
				        public void handle(CellEditEvent<User, Boolean> t) {
				            ((User) t.getTableView().getItems().get(
				                t.getTablePosition().getRow())
				                ).setExcused(true);
				        }
				    }
				);*/
			tableUser.setEditable(true);
			tableUser.setItems(data);
			

	}
	
	public void generateGradesReport() throws IOException, ClassNotFoundException, SQLException {
		TablePosition pos = tableUser.getSelectionModel().getSelectedCells().get(0);
		int row = pos.getRow();
		User user = data.get(row);
		int i = 0;
		
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd");
		LocalDate localDate = LocalDate.now();
		String imie = user.getName().replaceAll(" ", "");
		String nazwisko = user.getLastName().replaceAll(" ", "");
		Integer idUcznia = user.getIdUcznia();
		
		String fileName = imie+nazwisko+"_"+"GradesReport"+".pdf";
		fileName.replace(" ", "");
		PDDocument doc = new PDDocument();
		PDPage page = new PDPage();		
		doc.addPage(page);
		
		PDPageContentStream contentStream = new PDPageContentStream(doc, page); 
	    contentStream.beginText(); 
	    
	    contentStream.setLeading(23);
	    contentStream.newLineAtOffset(25, 725);
	    
	    String text1 = "Raport Ocen";
	    String text2 = "Imie: "+ imie;
	    String text3 = "Nazwisko: "+ nazwisko;
	    String text4 = "ID Ucznia: "+ idUcznia.toString();
	    String text5 = "Data : " + dtf.format(localDate);
	    String text6 = "ID";
	    String text7 = "Nazwa Przedmiotu";
	    String text8 = "Oceny";
	    String text9 = "Srednia ocen w semestrze";
	    
	    Connection con = MainApp.getConnection();
		
		ArrayList<Integer> idPrzedmiotow = new ArrayList();
		ArrayList<String> nazwyPrzedmiotow = new ArrayList();
		ArrayList<Float> oceny = new ArrayList();
		ResultSet rs=con.createStatement().executeQuery(
				"select _subject.id_przedmiotu from _subject, pupil, grades "
				+ "where _subject.id_przedmiotu = grades.id_przedmiotu "
				+ "and "
				+ "grades.id_ucznia = pupil.id_ucznia "
				+ "and "
				+ "pupil.id_ucznia = "+idUcznia
				+ "group by _subject.id_przedmiotu");
		while(rs.next()){
			idPrzedmiotow.add(rs.getInt("id_przedmiotu"));
		}
		rs=con.createStatement().executeQuery(
				"select _subject.nazwa from _subject, pupil, grades "
				+ "where _subject.id_przedmiotu = grades.id_przedmiotu "
				+ "and "
				+ "grades.id_ucznia = pupil.id_ucznia "
				+ "and "
				+ "pupil.id_ucznia = "+idUcznia
				+ "group by _subject.nazwa");
		while(rs.next()){
			nazwyPrzedmiotow.add(rs.getString("nazwa"));
		}
		for (i=0; i<nazwyPrzedmiotow.size(); i++) {
			rs=con.createStatement().executeQuery(
					"select ocena from _subject, pupil, grades "
					+ "where _subject.id_przedmiotu = grades.id_przedmiotu "
					+ "and "
					+ "grades.id_ucznia = pupil.id_ucznia "
					+ "and "
					+ "pupil.id_ucznia = "+idUcznia
					+ "and _subject.nazwa = '"+ nazwyPrzedmiotow.get(i) +"'");
			while(rs.next()){
				oceny.add(rs.getFloat("ocena"));
			}
		}
		
		ArrayList<String> textID = new ArrayList();
		ArrayList<String> textNazwa = new ArrayList();
		ArrayList<String> textOceny = new ArrayList();
		for(i=0; i<idPrzedmiotow.size(); i++) {
			textID.add(idPrzedmiotow.get(i).toString());
			textNazwa.add(nazwyPrzedmiotow.get(i));
			textOceny.add(oceny.get(i).toString());
		}
		contentStream.setFont(PDType1Font.TIMES_BOLD, 26);
		contentStream.moveTextPositionByAmount(200, 10);
		contentStream.showText(text1);
		contentStream.newLine();
		contentStream.newLine();
		contentStream.setFont(PDType1Font.TIMES_ROMAN, 18);
		contentStream.moveTextPositionByAmount(-200, 0);
		contentStream.showText(text2);
		contentStream.newLine();
		contentStream.showText(text3);
		contentStream.newLine();
		contentStream.showText(text4);
		contentStream.newLine();
		contentStream.showText(text5);
		contentStream.newLine();
		contentStream.newLine();
		contentStream.newLine();
		contentStream.setFont(PDType1Font.TIMES_BOLD, 20);
		contentStream.showText(text6);
		contentStream.moveTextPositionByAmount(80, 0);
		contentStream.showText(text7);
		contentStream.moveTextPositionByAmount(280, 0);
		contentStream.showText(text8);
		contentStream.newLine();
		contentStream.setFont(PDType1Font.TIMES_ROMAN, 18);
		contentStream.moveTextPositionByAmount(-360, 0);
		for(i=0; i<textID.size(); i++) {
			contentStream.showText(textID.get(i));
			contentStream.moveTextPositionByAmount(80, 0);
			contentStream.showText(textNazwa.get(i));
			contentStream.moveTextPositionByAmount(280, 0);
			contentStream.showText(textOceny.get(i));
			contentStream.newLine();
			contentStream.moveTextPositionByAmount(-360, 0);
		}
		contentStream.showText("_______________________________________________");
		contentStream.newLine();
		float srednia = 0;
		
		for(i=0; i<textOceny.size(); i++) {
			srednia += Float.valueOf(textOceny.get(i));
		}
		srednia = srednia/(textOceny.size()+1);
		String text10 = String.valueOf(srednia);
		contentStream.setFont(PDType1Font.TIMES_BOLD, 18);
		contentStream.showText(text9);
		contentStream.moveTextPositionByAmount(360, 0);
		contentStream.showText(text10);
		contentStream.newLine();
		contentStream.moveTextPositionByAmount(-360, 0);
		
		contentStream.endText();

		System.out.println("Content added");

		contentStream.close();
		doc.save(fileName);
		doc.close();
		MainApp.showInformation("Generacja raportu z ocenami", "Raport zosta� wygenerowany.", Alert.AlertType.INFORMATION);
	}	
	   @FXML
	   private Button View;
	   @FXML
	   private void goView(ActionEvent event){
		   try{
			   FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("Presents.fxml"));
			   Parent root1 = (Parent) fxmlLoader.load();
			   PresentsController controller = fxmlLoader.getController();
 			   controller.LoadDataFromDatabasePresents();
			   Stage stage = new Stage();
			   stage.setTitle("Podgl�d Obecno�ci");
			   stage.setScene(new Scene(root1));
			   stage.show();
			 //  mainApp.getStage().setResizable(false);
			   
			   
		   }catch(Exception e) {
			   e.printStackTrace();
			   System.out.println("Nie mozna zaladowac okna Adresu");
		   }
		   
	   }
	
}
