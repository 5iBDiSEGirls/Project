package projectCompetence.welcomeTeacher;

import java.io.IOException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import projectCompetence.MainApp;


public class TeacherController {

	private MainApp mainApp;
	
	private static AnchorPane rootLayout;

	@FXML
	private void LogoutButtonAction(ActionEvent event) throws Exception{
		if(MainApp.showQuestionDialog("Potwierdzenie", "Czy napewno chcesz sie wylogowa�?", "")) {
			mainApp.loadStage();
		}
	}

	public static void showTeacher(MainApp mainApp) {
		try {
		  	
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(MainApp.class.getResource("welcomeTeacher/Teacher.fxml"));
			rootLayout = loader.load();
			((TeacherController) loader.getController()).setMainApp(mainApp);
			Scene scene = new Scene(rootLayout);
			mainApp.getStage().setScene(scene);
			mainApp.getStage().setTitle("Nauczyciel");
		} catch (IOException e) {
		    e.printStackTrace();
		}
}

	private void setMainApp(MainApp mainApp) {
		this.mainApp = mainApp;
		
	}
}
