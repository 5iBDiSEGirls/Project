package test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class MainApp {

	public static void main(String[] args) {

		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			Connection con = DriverManager
					.getConnection("jdbc:sqlserver://project-competence.database.windows.net:1433;"
							+ "database=School;user=BDiSE@project-competence;password=dreamTeam1;encrypt=true;"
							+ "trustServerCertificate=false;hostNameInCertificate=*.database.windows.net;loginTimeout=30;");

			Statement s1 = con.createStatement();
			/*
			 * ResultSet rs = s1.
			 * executeQuery("SELECT nazwisko from pupil where imie like 'Daria'"
			 * ); String result = "";
			 * 
			 * if(rs!=null){ while (rs.next()){ result=rs.getString(1);
			 * System.out.println(result); } }
			 */

			// inserting data to database
			/*
			 * String sqlInsert =
			 * "insert into pupil values(118, 'Karolina', 'Nowacka', 'ul.Wigury 77, 35-907 ��d�', '609566867', 6, 'knowacka@uczen.pl', 'KhyR2Fcl')"
			 * ; s1.executeUpdate(sqlInsert);
			 */
			//

			// deleting data from database
			/*
			 * String sqlDelete =
			 * "delete from pupil where imie like 'Karolina' and nazwisko like 'Nowacka'"
			 * ; s1.executeUpdate(sqlDelete);
			 */
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
