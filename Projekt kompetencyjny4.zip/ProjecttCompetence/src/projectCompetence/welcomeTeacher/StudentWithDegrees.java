package projectCompetence.welcomeTeacher;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import javafx.beans.property.SimpleStringProperty;
import projectCompetence.Grade;

public class StudentWithDegrees {
	
	private String firstName;
	private String lastName;
	private List<Grade> grades = new ArrayList<>();
	
	
	public StudentWithDegrees(String firstName, String lastName) {
		this.firstName = firstName;
		this.lastName = lastName;
	}
	
	public void addGrade(Grade grade) {
		this.grades.add(grade);
	}
	
	public StudentWithDegreesRow getStudentWithDegreesRow() {
		String g1 = grades.stream().filter(g -> g.getWeight() == 1).map(Grade::getDegree).collect(Collectors.joining(", ")),
				g2 = grades.stream().filter(g -> g.getWeight() == 2).map(Grade::getDegree).collect(Collectors.joining(", ")),
				g3 = grades.stream().filter(g -> g.getWeight() == 3).map(Grade::getDegree).collect(Collectors.joining(", ")),
				g4 = grades.stream().filter(g -> g.getWeight() == 4).map(Grade::getDegree).collect(Collectors.joining(", ")),
				g5 = grades.stream().filter(g -> g.getWeight() == 5).map(Grade::getDegree).collect(Collectors.joining(", "));
		
		return new StudentWithDegreesRow(firstName, lastName, g1, g2, g3, g4, g5);
	}
	
	public class StudentWithDegreesRow {
	    
        private final SimpleStringProperty firstNameField;
        private final SimpleStringProperty lastNameField;
        private final SimpleStringProperty gradesWith1weight;
        private final SimpleStringProperty gradesWith2weight;
		private final SimpleStringProperty gradesWith3weight;
		private final SimpleStringProperty gradesWith4weight;
		private final SimpleStringProperty gradesWith5weight;
		private final SimpleStringProperty newGradeField;
		private final SimpleStringProperty newWeightField;

        private StudentWithDegreesRow(String firstNameField, String lastNameField, String gradesWith1weight, String gradesWith2weight, String gradesWith3weight, String gradesWith4weight, String gradesWith5weight) {
            this.firstNameField = new SimpleStringProperty(firstNameField);
            this.lastNameField = new SimpleStringProperty(lastNameField);
            this.gradesWith1weight = new SimpleStringProperty(gradesWith1weight);
            this.gradesWith2weight = new SimpleStringProperty(gradesWith2weight);
            this.gradesWith3weight = new SimpleStringProperty(gradesWith3weight);
            this.gradesWith4weight = new SimpleStringProperty(gradesWith4weight);
            this.gradesWith5weight = new SimpleStringProperty(gradesWith5weight);
            this.newGradeField = new SimpleStringProperty();
            this.newWeightField = new SimpleStringProperty();
        }

		

		public String getFirstNameField() {
			return firstNameField.get();
		}

		public void setFirstNameField(String value) {
			this.firstNameField.set(value);
		}

		public String getLastNameField() {
			return lastNameField.get();
		}

		public void setLastNameField(String value) {
			this.lastNameField.set(value);
		}

		public String getGradesWith1weight() {
			return gradesWith1weight.get();
		}

		public void setGradesWith1weight(String value) {
			this.gradesWith1weight.set(value);
		}

		public String getGradesWith2weight() {
			return gradesWith2weight.get();
		}

		public void setGradesWith2weight(String value) {
			this.gradesWith2weight.set(value);
		}

		public String getGradesWith3weight() {
			return gradesWith3weight.get();
		}

		public void setGradesWith3weight(String value) {
			this.gradesWith3weight.set(value);
		}

		public String getGradesWith4weight() {
			return gradesWith4weight.get();
		}

		public void setGradesWith4weight(String value) {
			this.gradesWith4weight.set(value);
		}

		public String getGradesWith5weight() {
			return gradesWith5weight.get();
		}

		public void setGradesWith5weight(String value) {
			this.gradesWith5weight.set(value);
		}

		public String getNewGradeField() {
			return newGradeField.get();
		}

		public void setNewGradeField(String value) {
			this.newGradeField.set(value);
		}

		public String getNewWeightField() {
			return newWeightField.get();
		}
		
		public void setNewWeightField(String value) {
			this.newWeightField.set(value);
		}

		@Override
		public String toString() {
			return "StudentWithDegreesRow [firstNameField=" + firstNameField + ", lastNameField=" + lastNameField
					+ ", gradesWith1weight=" + gradesWith1weight + ", gradesWith2weight=" + gradesWith2weight
					+ ", gradesWith3weight=" + gradesWith3weight + ", gradesWith4weight=" + gradesWith4weight
					+ ", gradesWith5weight=" + gradesWith5weight + ", newGradeField=" + newGradeField
					+ ", newWeightField=" + newWeightField + "]";
		}
        
		
    }
}
